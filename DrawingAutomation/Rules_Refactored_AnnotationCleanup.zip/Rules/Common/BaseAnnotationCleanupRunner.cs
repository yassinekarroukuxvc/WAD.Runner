using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using SolidWorks.Interop.sldworks;
using WAD.Runner.Application;
using WAD.Runner.DataManagement.Domain.Drawing;
using WAD.Runner.DataManagement.Domain.Units;
using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.DrawingAutomation.SolidWorks;
using WAD.Runner.DrawingAutomation.Views;
using DomDim = WAD.Runner.DataManagement.Domain.Dimensions.Dimension;

namespace WAD.Runner.DrawingAutomation.Rules.Common;

public abstract class BaseAnnotationCleanupRunner : IDrawingCleanupRunner
{
    public abstract WedgeType AppliesTo { get; }
    protected abstract string LogPrefix { get; }

    protected abstract IReadOnlyList<SharedAnnotationDeletionRules.DeletionTarget> PlanDeletions(
        ModelDoc2 model,
        SharedAnnotationDeletionRules.DrawingType drawingType,
        SharedAnnotationDeletionRules.ShankType shank,
        SharedAnnotationDeletionRules.FootOption foot,
        SharedAnnotationDeletionRules.Options options,
        SharedAnnotationDeletionRules.ViewNameMap viewNames,
        bool activateEachView);

    protected virtual void DumpExistingForDebug(
        ModelDoc2 model,
        SharedAnnotationDeletionRules.ViewNameMap viewNames,
        bool activateEachView)
    {
        SharedAnnotationDeletionRules.DumpExistingDimensionNames(
            LogPrefix,
            model,
            viewNames,
            activateEachView);
    }

    public void TryApply(
        DrawingService ds,
        IDictionary<string, string> nameMap,
        DrawingRun run,
        DrawingData drawingData,
        bool activateEachView = true)
    {
        try
        {
            if (run is null) throw new ArgumentNullException(nameof(run));
            if (drawingData is null) throw new ArgumentNullException(nameof(drawingData));

            if (run.WedgeType != AppliesTo)
            {
                Logger.Info($"[{LogPrefix}.Cleanup] Skipped because run wedge type is {run.WedgeType}, not {AppliesTo}.");
                return;
            }

            if (ds?.Model is not ModelDoc2 model)
            {
                Logger.Warn($"[{LogPrefix}.Cleanup] DrawingService.Model is null or not ModelDoc2; skipping annotation cleanup.");
                return;
            }

            var viewNames = BuildViewNameMap(nameMap);
            var (shank, foot) = ResolveShankAndFoot(run.Wedge);
            var drawingType = ResolveDrawingType(run, drawingData);
            var options = BuildOptions(run.Wedge);

            Logger.Blue($"[{LogPrefix}.Cleanup] DrawingType={drawingType}, Shank={shank}, Foot={foot}");

            var deletions = PlanDeletions(model, drawingType, shank, foot, options, viewNames, activateEachView);

            if (deletions == null || deletions.Count == 0)
            {
                Logger.Warn($"[{LogPrefix}.Plan] Planned deletions = 0. Dumping existing dimensions for diagnostics.");
                DumpExistingForDebug(model, viewNames, activateEachView);
                return;
            }

            SharedAnnotationDeletionRules.DumpDeletionPlan(LogPrefix, $"{LogPrefix} Cleanup Runner", deletions);

            var totalDeleted = 0;
            foreach (var group in deletions.GroupBy(d => d.ViewName, StringComparer.OrdinalIgnoreCase))
            {
                var fullNames = group.Select(x => x.AnnotationFullName).ToList();
                var deletedInView = AnnotationCleanupService.RemoveDimensionsByFullNamesInView(
                    ds,
                    nameMap,
                    logicalViewName: group.Key,
                    fullNames: fullNames);

                totalDeleted += deletedInView;
                Logger.Info($"[{LogPrefix}.Plan] Deleted in view '{group.Key}': {deletedInView}/{fullNames.Count} planned.");
            }

            Logger.Info($"[{LogPrefix}.Plan] Total deleted annotations: {totalDeleted}");
        }
        catch (Exception ex)
        {
            Logger.Warn($"[{LogPrefix}.Cleanup] Failed; continuing drawing automation. {ex.Message}");
        }
    }

    protected static SharedAnnotationDeletionRules.ViewNameMap BuildViewNameMap(IDictionary<string, string> nameMap)
        => new()
        {
            Front = ResolveView(nameMap, "Front"),
            Side = ResolveView(nameMap, "Side"),
            Top = ResolveView(nameMap, "Top"),
            Detail = ResolveView(nameMap, "Detail"),
            Section = ResolveView(nameMap, "Section")
        };

    private static string ResolveView(IDictionary<string, string> nameMap, string logical)
    {
        if (nameMap != null && nameMap.TryGetValue(logical, out var mapped) && !string.IsNullOrWhiteSpace(mapped))
            return mapped.Trim();
        return logical;
    }

    protected static SharedAnnotationDeletionRules.DrawingType ResolveDrawingType(DrawingRun run, DrawingData drawingData)
    {
        var drawingTypeText = drawingData?.DrawingType.ToString() ?? string.Empty;
        var isOverlay = drawingTypeText.Equals("Overlay", StringComparison.OrdinalIgnoreCase);
        var isCustomer = drawingTypeText.Equals("Customer", StringComparison.OrdinalIgnoreCase);
        var isPgb = run?.Wedge?.Subclass == WedgeSubclass.PGB;

        if (isPgb && isOverlay) return SharedAnnotationDeletionRules.DrawingType.PgbOverlay;
        if (isPgb) return SharedAnnotationDeletionRules.DrawingType.Pgb;
        if (isOverlay) return SharedAnnotationDeletionRules.DrawingType.Overlay;
        if (isCustomer) return SharedAnnotationDeletionRules.DrawingType.Customer;
        return SharedAnnotationDeletionRules.DrawingType.Production;
    }

    protected (SharedAnnotationDeletionRules.ShankType Shank, SharedAnnotationDeletionRules.FootOption Foot)
        ResolveShankAndFoot(WedgeData wedge)
    {
        var wedType = GetPropLoose(wedge, "Wed-Type");
        var footOption = GetPropLoose(wedge, "Wed-Foot_Option");

        Logger.Blue($"[{LogPrefix}.Resolve] Wed-Type={wedType ?? "(null)"}, Wed-Foot_Option={footOption ?? "(null)"}");

        return (ParseShankType(wedType), ResolveFootOption(wedge, footOption));
    }

    protected SharedAnnotationDeletionRules.Options BuildOptions(WedgeData wedge)
    {
        bool Pos(string key) => IsDimPositive(wedge, key);

        var hasVr = Pos("VR");
        var hasVw = Pos("VW");
        var hasVwVr = hasVr && hasVw;
        var hasVra = Pos("VRA");
        var hasX = Pos("X");
        var hasFx = Pos("FX");
        var hasVfl = Pos("VFL");
        var hasVbl = Pos("VBL");
        var hasW2 = Pos("W2");
        var hasGa = Pos("GA");
        var hasCd = Pos("CD");
        var hasGd = Pos("GD");
        var hasGr = Pos("GR");
        var hasB = Pos("B");
        var hasRa2 = Pos("RA2");
        var hasErd = Pos("ERD");
        var hasFr = Pos("FR");
        var hasBr = Pos("BR");
        var hasF = Pos("F");
        var hasG = Pos("G");
        var hasCgr = Pos("CGR");
        var hasCgd = Pos("CGD");
        var hasCbra = Pos("CBRA");
        var hasCbrl = Pos("CBRL");

        Logger.Blue(
            $"[{LogPrefix}.Options] VW={hasVw}, VR={hasVr}, VW/VR={hasVwVr}, VRA={hasVra}, X={hasX}, FX={hasFx}, VFL={hasVfl}, VBL={hasVbl}, " +
            $"W2={hasW2}, GA={hasGa}, CD={hasCd}, GD={hasGd}, GR={hasGr}, B={hasB}, " +
            $"RA2={hasRa2}, ERD={hasErd}, FR={hasFr}, BR={hasBr}, F={hasF}, G={hasG}, CGR={hasCgr}, CGD={hasCgd}, CBRA={hasCbra}, CBRL={hasCbrl}");

        foreach (var key in new[]
        {
            "VW", "VR", "VRA", "X", "FX", "VFL", "VBL", "W2", "GA", "CD", "GD", "GR", "B",
            "RA2", "ERD", "FR", "BR", "F", "G", "CGR", "CGD", "CBRA", "CBRL"
        })
        {
            DumpDim(wedge, key);
        }

        return new SharedAnnotationDeletionRules.Options
        {
            HasVwVr = hasVwVr,
            HasVw = hasVw,
            HasVr = hasVr,
            HasVra = hasVra,
            HasX = hasX,
            HasFx = hasFx,
            HasVfl = hasVfl,
            HasSlb = hasVbl,
            HasW2 = hasW2,
            HasGa = hasGa,
            HasCd = hasCd,
            HasGd = hasGd,
            HasGr = hasGr,
            HasB = hasB,
            HasRa2 = hasRa2,
            HasErd = hasErd,
            HasFr = hasFr,
            HasBr = hasBr,
            HasF = hasF,
            HasG = hasG,
            HasCgr = hasCgr,
            HasCgd = hasCgd,
            HasCbra = hasCbra,
            HasCbrl = hasCbrl
        };
    }

    protected static bool IsDimPositive(WedgeData wedge, string key)
    {
        if (!TryGetDim(wedge, key, out var dim) || dim is null) return false;

        try
        {
            var value = dim.Nominal.Unit == UnitKind.Degree
                ? (double)dim.Nominal.AsDeg()
                : (double)dim.Nominal.AsMm();
            return value > 1e-12;
        }
        catch
        {
            return false;
        }
    }

    private void DumpDim(WedgeData wedge, string key)
    {
        if (!TryGetDim(wedge, key, out var dim) || dim is null)
        {
            Logger.Info($"[{LogPrefix}.OptionsDbg] {key}: (missing)");
            return;
        }

        try
        {
            var value = dim.Nominal.Unit == UnitKind.Degree
                ? (double)dim.Nominal.AsDeg()
                : (double)dim.Nominal.AsMm();
            Logger.Info($"[{LogPrefix}.OptionsDbg] {key}: {value.ToString("0.#####", CultureInfo.InvariantCulture)} ({dim.Nominal.Unit})");
        }
        catch (Exception ex)
        {
            Logger.Info($"[{LogPrefix}.OptionsDbg] {key}: (unreadable) {ex.Message}");
        }
    }

    private static bool TryGetDim(WedgeData wedge, string key, out DomDim? dim)
    {
        dim = null;
        if (wedge?.Dimensions == null || wedge.Dimensions.Count == 0 || string.IsNullOrWhiteSpace(key))
            return false;

        var want = NormalizeBaseKey(key);
        foreach (var kv in wedge.Dimensions)
        {
            var haveRaw = kv.Key.Value ?? kv.Key.ToString() ?? string.Empty;
            if (NormalizeBaseKey(haveRaw).Equals(want, StringComparison.OrdinalIgnoreCase))
            {
                dim = kv.Value;
                return dim is not null;
            }
        }

        return false;
    }

    private static string NormalizeBaseKey(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return string.Empty;
        var s = raw.Trim().ToUpperInvariant();
        var at = s.IndexOf('@');
        if (at >= 0) s = s[..at];
        s = s.Replace("-", "_").Replace(" ", "_").Replace("(", "_").Replace(")", string.Empty);
        return new string(s.Where(char.IsLetterOrDigit).ToArray());
    }

    protected static string? GetPropLoose(WedgeData wedge, string key)
    {
        if (wedge?.Properties == null || string.IsNullOrWhiteSpace(key)) return null;

        if (wedge.Properties.TryGetValue(key, out var value))
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();

        foreach (var kv in wedge.Properties)
            if (string.Equals(kv.Key, key, StringComparison.OrdinalIgnoreCase))
                return string.IsNullOrWhiteSpace(kv.Value) ? null : kv.Value.Trim();

        return null;
    }

    protected static SharedAnnotationDeletionRules.ShankType ParseShankType(string? wedType)
    {
        var s = (wedType ?? string.Empty).Trim().ToUpperInvariant();
        return s.Contains("180") || s.Contains("REV")
            ? SharedAnnotationDeletionRules.ShankType.Deg180Rev
            : SharedAnnotationDeletionRules.ShankType.Std;
    }

    protected static SharedAnnotationDeletionRules.FootOption ResolveFootOption(WedgeData wedge, string? rawFoot)
    {
        var s = NormalizeToken(rawFoot)
             ?? NormalizeToken(GetPropLoose(wedge, "Wed-Foot_Option"))
             ?? NormalizeToken(GetPropLoose(wedge, "Foot_Option"))
             ?? NormalizeToken(GetPropLoose(wedge, "FootOption"))
             ?? NormalizeToken(GetPropLoose(wedge, "foot_option"));

        if (string.IsNullOrWhiteSpace(s))
            return SharedAnnotationDeletionRules.FootOption.None;

        var baseFoot = s switch
        {
            "SW_C" => SharedAnnotationDeletionRules.FootOption.C,
            "SW_G" => SharedAnnotationDeletionRules.FootOption.G,
            "SW_VG" => SharedAnnotationDeletionRules.FootOption.VG,
            "SW_CG" => SharedAnnotationDeletionRules.FootOption.CG,
            "SW_CC" => SharedAnnotationDeletionRules.FootOption.CC,
            _ => SharedAnnotationDeletionRules.FootOption.None
        };

        if (baseFoot == SharedAnnotationDeletionRules.FootOption.C)
        {
            var hasCbr = IsDimPositive(wedge, "CBRA") &&
                         IsDimPositive(wedge, "CBRL") &&
                         IsDimPositive(wedge, "CBRD");
            if (hasCbr) return SharedAnnotationDeletionRules.FootOption.C_WITH_CBR;
        }

        return baseFoot;
    }

    private static string? NormalizeToken(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var s = value.Trim().ToUpperInvariant().Replace("-", "_").Replace(" ", "_");
        s = new string(s.Where(c => char.IsLetterOrDigit(c) || c == '_').ToArray());
        return string.IsNullOrWhiteSpace(s) ? null : s;
    }
}
