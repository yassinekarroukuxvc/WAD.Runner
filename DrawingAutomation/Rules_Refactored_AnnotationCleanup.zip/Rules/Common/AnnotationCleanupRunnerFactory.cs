using System.Collections.Generic;
using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.DrawingAutomation.Rules.CKVD;
using WAD.Runner.DrawingAutomation.Rules.COB;
using WAD.Runner.DrawingAutomation.Rules.FP;
using WAD.Runner.DrawingAutomation.Rules.OSG7;
using WAD.Runner.DrawingAutomation.Rules.UTUS;

namespace WAD.Runner.DrawingAutomation.Rules.Common;

public static class AnnotationCleanupRunnerFactory
{
    private static readonly IReadOnlyDictionary<WedgeType, IDrawingCleanupRunner> Registry =
        new Dictionary<WedgeType, IDrawingCleanupRunner>
        {
            [WedgeType.CKVD] = new CkvdAnnotationCleanupRunner(),
            [WedgeType.COB] = new CobAnnotationCleanupRunner(),
            [WedgeType.UTUS] = new UtusAnnotationCleanupRunner(),
            [WedgeType.FP] = new FpAnnotationCleanupRunner(),
            [WedgeType.OSG7] = new Osg7AnnotationCleanupRunner()
        };

    public static IDrawingCleanupRunner? TryGet(WedgeType wedgeType)
        => Registry.TryGetValue(wedgeType, out var runner) ? runner : null;

    public static bool HasRunner(WedgeType wedgeType)
        => Registry.ContainsKey(wedgeType);
}
