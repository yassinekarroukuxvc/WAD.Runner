using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using SolidWorks.Interop.sldworks;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Catalogs;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Engine;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Resolution;
using CleanupFootOption = WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain.FootOption;
using CleanupProfile = WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain.AnnotationCleanupProfile;
using CleanupShankType = WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain.ShankType;

namespace WAD.Runner.DrawingAutomation.Rules.Common;

/// <summary>
/// Compatibility facade for older COB/FP/UTUS wrappers.
/// The old public API is preserved, but the keep-set is now built from the new declarative rule catalogs.
/// </summary>
public static class SharedAnnotationDeletionRules
{
    public static bool RulesEnabled { get; set; } = true;

    public enum DrawingType { Pgb, Production, Customer, Overlay, PgbOverlay }
    public enum ShankType { Std, Deg180Rev }
    public enum FootOption { None, C, G, VG, CG, CC, C_WITH_CBR }
    public enum ViewKind { Front, Side, Top, Detail, Section }

    public sealed record DeletionTarget(string ViewName, string AnnotationFullName);

    public sealed class Options
    {
        public bool HasVwVr { get; init; }
        public bool HasVw { get; init; }
        public bool HasVr { get; init; }
        public bool HasX { get; init; }
        public bool HasFx { get; init; }
        public bool HasVfl { get; init; }
        public bool HasSlb { get; init; }
        public bool HasVra { get; init; }
        public bool HasW2 { get; init; }
        public bool HasGa { get; init; }
        public bool HasCd { get; init; }
        public bool HasGd { get; init; }
        public bool HasGr { get; init; }
        public bool HasB { get; init; }
        public bool HasRa2 { get; init; }
        public bool HasErd { get; init; }
        public bool HasFr { get; init; }
        public bool HasBr { get; init; }
        public bool HasFrBr => HasFr && HasBr;
        public bool HasF { get; init; }
        public bool HasG { get; init; }
        public bool HasCgr { get; init; }
        public bool HasCgd { get; init; }
        public bool HasCbra { get; init; }
        public bool HasCbrl { get; init; }
        public string? KAnnotationFullName { get; init; }
        public string? ErdAnnotationFullName { get; init; }
    }

    public sealed class ViewNameMap
    {
        public string Front { get; init; } = "Front View";
        public string Side { get; init; } = "Side View";
        public string Top { get; init; } = "Top View";
        public string Detail { get; init; } = "Detail View";
        public string Section { get; init; } = "Section View";

        public string Resolve(ViewKind kind) => kind switch
        {
            ViewKind.Front => Front,
            ViewKind.Side => Side,
            ViewKind.Top => Top,
            ViewKind.Detail => Detail,
            ViewKind.Section => Section,
            _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, null)
        };

        internal AnnotationDeletionCore.ViewNameMap ToCore() => new()
        {
            Front = Front,
            Side = Side,
            Top = Top,
            Detail = Detail,
            Section = Section
        };

        internal AnnotationViewNameMap ToDomain() => new()
        {
            Front = Front,
            Side = Side,
            Top = Top,
            Detail = Detail,
            Section = Section
        };
    }

    public static void DumpDeletionPlan(
        string tagPrefix,
        string title,
        IReadOnlyList<DeletionTarget> deletions,
        int maxPerView = 200)
    {
        var core = (deletions ?? Array.Empty<DeletionTarget>())
            .Select(d => new AnnotationDeletionCore.DeletionTarget(d.ViewName, d.AnnotationFullName))
            .ToList()
            .AsReadOnly();

        AnnotationDeletionCore.DumpDeletionPlan(title, core, tagPrefix, maxPerView);
    }

    public static void DumpExistingDimensionNames(
        string tagPrefix,
        ModelDoc2 drawingModel,
        ViewNameMap? viewNames = null,
        bool activateEachView = true,
        int maxPerView = 250)
    {
        if (drawingModel is null) throw new ArgumentNullException(nameof(drawingModel));

        AnnotationDeletionCore.DumpExistingDisplayDimensionFullNamesFromDrawing(
            drawingModel,
            (viewNames ?? new ViewNameMap()).ToCore(),
            tagPrefix,
            activateEachView,
            maxPerView);
    }

    public static IReadOnlyList<DeletionTarget> GetAnnotationsToDelete(
        DrawingType drawingType,
        ShankType shankType,
        FootOption footOption,
        Options? options = null,
        ViewNameMap? viewNames = null)
    {
        if (!RulesEnabled) return Empty();

        options ??= new Options();
        viewNames ??= new ViewNameMap();

        var ctx = CreateContext(drawingType, shankType, footOption, options, viewNames);
        var keep = BuildKeepSet(ctx);
        var all = BuildAllKnownAnnotations();

        return AnnotationDeletionCore
            .GetAnnotationsToDelete_FromKnownSuperset(keep, all, viewNames.ToCore())
            .Select(d => new DeletionTarget(d.ViewName, d.AnnotationFullName))
            .ToList()
            .AsReadOnly();
    }

    public static IReadOnlyList<DeletionTarget> GetExistingAnnotationsToDelete_FromKnownSuperset(
        DrawingType drawingType,
        ShankType shankType,
        FootOption footOption,
        IReadOnlyDictionary<string, IReadOnlyCollection<string>> existingByViewName,
        Options? options = null,
        ViewNameMap? viewNames = null)
    {
        if (!RulesEnabled) return Empty();
        if (existingByViewName is null) throw new ArgumentNullException(nameof(existingByViewName));

        options ??= new Options();
        viewNames ??= new ViewNameMap();

        var candidates = GetAnnotationsToDelete(drawingType, shankType, footOption, options, viewNames)
            .Select(c => new AnnotationDeletionCore.DeletionTarget(c.ViewName, c.AnnotationFullName))
            .ToList()
            .AsReadOnly();

        return AnnotationDeletionCore
            .FilterCandidatesByExisting_FromKnownSuperset(candidates, existingByViewName)
            .Select(d => new DeletionTarget(d.ViewName, d.AnnotationFullName))
            .ToList()
            .AsReadOnly();
    }

    public static IReadOnlyList<DeletionTarget> PlanDeletionsFromDrawing(
        ModelDoc2 drawingModel,
        DrawingType drawingType,
        ShankType shankType,
        FootOption footOption,
        Options? options = null,
        ViewNameMap? viewNames = null,
        bool activateEachView = true)
    {
        if (drawingModel is null) throw new ArgumentNullException(nameof(drawingModel));
        if (!RulesEnabled) return Empty();

        options ??= new Options();
        viewNames ??= new ViewNameMap();

        var ctx = CreateContext(drawingType, shankType, footOption, options, viewNames);
        var planner = new AnnotationCleanupPlanner(AnnotationRuleCatalogRegistry.CreateDefault());
        var stateReader = new DrawingAnnotationStateReader();
        var executor = new AnnotationCleanupExecutor(planner, stateReader);

        return executor
            .PlanDeletions(drawingModel, ctx, activateEachView)
            .Select(d => new DeletionTarget(d.ViewName, d.AnnotationFullName))
            .ToList()
            .AsReadOnly();
    }

    public static IReadOnlyList<DeletionTarget> PlanDeletionsFromDrawing_FromKnownSuperset(
        ModelDoc2 drawingModel,
        DrawingType drawingType,
        ShankType shankType,
        FootOption footOption,
        Options? options = null,
        ViewNameMap? viewNames = null,
        bool activateEachView = true)
    {
        if (drawingModel is null) throw new ArgumentNullException(nameof(drawingModel));
        if (!RulesEnabled) return Empty();

        options ??= new Options();
        viewNames ??= new ViewNameMap();

        var existingByView = AnnotationDeletionCore.CollectExistingDisplayDimensionFullNamesByView(
            drawingModel,
            viewNames.ToCore(),
            activateEachView);

        return GetExistingAnnotationsToDelete_FromKnownSuperset(
            drawingType,
            shankType,
            footOption,
            existingByView,
            options,
            viewNames);
    }

    public static HashSet<AnnotationDeletionCore.Ann> BuildKeepSetForDiagnostics(
        DrawingType drawingType,
        ShankType shankType,
        FootOption footOption,
        Options? options = null,
        ViewNameMap? viewNames = null)
    {
        options ??= new Options();
        viewNames ??= new ViewNameMap();
        return BuildKeepSet(CreateContext(drawingType, shankType, footOption, options, viewNames));
    }

    private static HashSet<AnnotationDeletionCore.Ann> BuildKeepSet(AnnotationCleanupContext ctx)
    {
        var planner = new AnnotationCleanupPlanner(AnnotationRuleCatalogRegistry.CreateDefault());
        return planner.BuildCoreKeepSet(ctx);
    }

    private static AnnotationCleanupContext CreateContext(
        DrawingType drawingType,
        ShankType shankType,
        FootOption footOption,
        Options options,
        ViewNameMap viewNames)
    {
        var dimensions = DimensionFacts.FromBooleans(new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase)
        {
            ["VW"] = options.HasVw || options.HasVwVr,
            ["VR"] = options.HasVr || options.HasVwVr,
            ["VRA"] = options.HasVra,
            ["X"] = options.HasX,
            ["FX"] = options.HasFx,
            ["VFL"] = options.HasVfl,
            ["VBL"] = options.HasSlb,
            ["SLB"] = options.HasSlb,
            ["W2"] = options.HasW2,
            ["GA"] = options.HasGa,
            ["CD"] = options.HasCd,
            ["GD"] = options.HasGd,
            ["GR"] = options.HasGr,
            ["B"] = options.HasB,
            ["RA2"] = options.HasRa2,
            ["ERD"] = options.HasErd,
            ["FR"] = options.HasFr,
            ["BR"] = options.HasBr,
            ["F"] = options.HasF,
            ["G"] = options.HasG,
            ["CGR"] = options.HasCgr,
            ["CGD"] = options.HasCgd,
            ["CBRA"] = options.HasCbra,
            ["CBRL"] = options.HasCbrl
        });

        return AnnotationCleanupContextFactory.CreateFromResolvedInputs(
            ToProfile(drawingType),
            ToDomain(shankType),
            ToDomain(footOption),
            dimensions,
            viewNames.ToDomain(),
            options.KAnnotationFullName,
            options.ErdAnnotationFullName);
    }

    private static CleanupProfile ToProfile(DrawingType drawingType) => drawingType switch
    {
        DrawingType.Pgb => CleanupProfile.PgbProduction,
        DrawingType.PgbOverlay => CleanupProfile.PgbOverlay,
        DrawingType.Production => CleanupProfile.CobLikeProduction,
        DrawingType.Customer => CleanupProfile.CobLikeCustomer,
        DrawingType.Overlay => CleanupProfile.CobLikeOverlay,
        _ => throw new ArgumentOutOfRangeException(nameof(drawingType), drawingType, null)
    };

    private static CleanupShankType ToDomain(ShankType shank) => shank switch
    {
        ShankType.Std => CleanupShankType.Std,
        ShankType.Deg180Rev => CleanupShankType.Deg180Rev,
        _ => throw new ArgumentOutOfRangeException(nameof(shank), shank, null)
    };

    private static CleanupFootOption ToDomain(FootOption foot) => foot switch
    {
        FootOption.None => CleanupFootOption.None,
        FootOption.C => CleanupFootOption.C,
        FootOption.G => CleanupFootOption.G,
        FootOption.VG => CleanupFootOption.VG,
        FootOption.CG => CleanupFootOption.CG,
        FootOption.CC => CleanupFootOption.CC,
        FootOption.C_WITH_CBR => CleanupFootOption.C_WITH_CBR,
        _ => throw new ArgumentOutOfRangeException(nameof(foot), foot, null)
    };

    public static string FrontSketch(ShankType shank)
        => shank == ShankType.Std ? "ANNOT_STD_FRONT_sketch" : "ANNOT_180_DEG_REV_FRONT_sketch";

    public static string TopSketch(ShankType shank)
        => shank == ShankType.Std ? "ANNOT_STD_TOP_sketch" : "ANNOT_180_DEG_REV_TOP_sketch";

    public static string FrBrSketch(ShankType shank)
        => shank == ShankType.Std ? "ANNOT_FR_BR_STD_FRONT_sketch" : "ANNOT_FR_BR_180_DEG_REV_FRONT_sketch";

    private static HashSet<AnnotationDeletionCore.Ann> BuildAllKnownAnnotations()
    {
        var all = new HashSet<AnnotationDeletionCore.Ann>();

        foreach (var shank in BothShanks)
        {
            var fs = FrontSketch(shank);
            var ts = TopSketch(shank);
            var frbr = FrBrSketch(shank);

            Add(all, V.Front, $"TL@{fs}");
            Add(all, V.Front, "TL@part_axis");
            Add(all, V.Front, "TL@ANNOT_LEFT_sketch");
            Add(all, V.Front, "VR@ANNOT_LEFT_sketch");
            Add(all, V.Front, "K@Engraving");
            Add(all, V.Front, "K@ANNOT_LEFT_sketch");

            Add(all, V.Side, $"BA@{fs}");
            Add(all, V.Side, $"TL@{fs}");
            Add(all, V.Side, $"VBL@{fs}");

            Add(all, V.Top, $"TD@{ts}");
            Add(all, V.Top, $"TDF@{ts}");

            foreach (var dim in AllSectionCavityDims)
                Add(all, V.Section, $"{dim}@{fs}");

            foreach (var dim in new[] { "FL_C", "FL_G", "FL_VG" })
                Add(all, V.Section, $"{dim}@{fs}");

            foreach (var dim in CgDims)
                Add(all, V.Section, $"{dim}@{fs}");

            Add(all, V.Section, $"CBRA@{fs}");
            Add(all, V.Section, $"CBRL@{fs}");

            foreach (var suffix in FrBrSuffixes)
            {
                Add(all, V.Section, $"FR_{suffix}@{frbr}");
                Add(all, V.Section, $"BR_{suffix}@{frbr}");
            }

            if (shank == ShankType.Deg180Rev)
            {
                foreach (var dim in CgDims)
                    Add(all, V.Section, $"{dim}@ANNOT_180_DEG_REV_FRONT_FRONT_sketch");
            }
        }

        foreach (var dim in new[] { "W", "ISA", "VW", "VR", "VRA", "W2" })
            Add(all, V.Detail, $"{dim}@ANNOT_LEFT_sketch");

        foreach (var dim in new[] { "CD", "CR", "GD", "GR_G", "GR_VG", "GA", "B" })
            Add(all, V.Detail, $"{dim}@ANNOT_FOOT_OPTIONS_LEFT_sketch");

        return all;
    }

    private static void Add(HashSet<AnnotationDeletionCore.Ann> set, AnnotationDeletionCore.ViewKind view, string fullName)
        => set.Add(new AnnotationDeletionCore.Ann(view, fullName));

    private static IReadOnlyList<DeletionTarget> Empty()
        => new ReadOnlyCollection<DeletionTarget>(new List<DeletionTarget>());

    private static readonly string[] AllSectionCavityDims =
        { "T", "FD", "ERL", "ERD", "CA", "H", "HA", "FNA", "RA", "RA2", "BA" };

    private static readonly string[] CgDims = { "G", "CGR", "CGD" };
    private static readonly string[] FrBrSuffixes = { "C", "G", "VG" };
    private static readonly ShankType[] BothShanks = { ShankType.Std, ShankType.Deg180Rev };

    private static class V
    {
        internal static readonly AnnotationDeletionCore.ViewKind Front = AnnotationDeletionCore.ViewKind.Front;
        internal static readonly AnnotationDeletionCore.ViewKind Side = AnnotationDeletionCore.ViewKind.Side;
        internal static readonly AnnotationDeletionCore.ViewKind Top = AnnotationDeletionCore.ViewKind.Top;
        internal static readonly AnnotationDeletionCore.ViewKind Detail = AnnotationDeletionCore.ViewKind.Detail;
        internal static readonly AnnotationDeletionCore.ViewKind Section = AnnotationDeletionCore.ViewKind.Section;
    }
}
