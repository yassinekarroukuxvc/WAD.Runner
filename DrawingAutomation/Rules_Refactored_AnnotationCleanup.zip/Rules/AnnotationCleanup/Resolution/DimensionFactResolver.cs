using System;
using System.Collections.Generic;
using System.Globalization;
using WAD.Runner.Application;
using WAD.Runner.DataManagement.Domain.Dimensions;
using WAD.Runner.DataManagement.Domain.Units;
using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;
using DomDim = WAD.Runner.DataManagement.Domain.Dimensions.Dimension;

namespace WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Resolution;

public static class DimensionFactResolver
{
    private static readonly string[] KnownKeys =
    {
        "VW", "VR", "VRA", "X", "FX", "VFL", "VBL", "W2", "GA", "CD", "GD", "GR", "B",
        "RA2", "ERD", "FR", "BR", "F", "G", "CGR", "CGD", "CBRA", "CBRL", "CBRD"
    };

    public static DimensionFacts Resolve(WedgeData wedge, string logPrefix = "AnnotationCleanup")
    {
        var facts = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        foreach (var key in KnownKeys)
        {
            facts[key] = IsDimensionPositive(wedge, key);
            DumpDimension(wedge, key, facts[key], logPrefix);
        }

        // Legacy alias: old code called VBL presence HasSlb.
        facts["SLB"] = facts.TryGetValue("VBL", out var hasVbl) && hasVbl;

        return DimensionFacts.FromBooleans(facts);
    }

    public static bool IsDimensionPositive(WedgeData wedge, string key)
    {
        if (!TryGetDimension(wedge, key, out var dim) || dim is null) return false;

        try
        {
            var value = dim.Nominal.Unit == UnitKind.Degree
                ? (double)dim.Nominal.AsDeg()
                : (double)dim.Nominal.AsMm();

            return value > 1e-12;
        }
        catch
        {
            return false;
        }
    }

    public static bool TryGetDimension(WedgeData wedge, string key, out DomDim? dimension)
    {
        dimension = null;
        if (wedge?.Dimensions == null || wedge.Dimensions.Count == 0 || string.IsNullOrWhiteSpace(key))
            return false;

        var want = DimensionFacts.Normalize(key);
        foreach (var kv in wedge.Dimensions)
        {
            var haveRaw = kv.Key.Value ?? kv.Key.ToString() ?? string.Empty;
            if (DimensionFacts.Normalize(haveRaw).Equals(want, StringComparison.OrdinalIgnoreCase))
            {
                dimension = kv.Value;
                return dimension is not null;
            }
        }

        return false;
    }

    private static void DumpDimension(WedgeData wedge, string key, bool isPositive, string logPrefix)
    {
        if (!TryGetDimension(wedge, key, out var dim) || dim is null)
        {
            Logger.Info($"[{logPrefix}.OptionsDbg] {key}: (missing)");
            return;
        }

        try
        {
            var value = dim.Nominal.Unit == UnitKind.Degree
                ? (double)dim.Nominal.AsDeg()
                : (double)dim.Nominal.AsMm();

            Logger.Info($"[{logPrefix}.OptionsDbg] {key}: {value.ToString("0.#####", CultureInfo.InvariantCulture)} ({dim.Nominal.Unit}) positive={isPositive}");
        }
        catch (Exception ex)
        {
            Logger.Info($"[{logPrefix}.OptionsDbg] {key}: (unreadable) {ex.Message}");
        }
    }
}
