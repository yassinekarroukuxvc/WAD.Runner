using System;
using WAD.Runner.DataManagement.Domain.Drawing;
using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;

namespace WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Resolution;

public static class DrawingProfileResolver
{
    public static AnnotationCleanupProfile Resolve(DrawingRun run, DrawingData drawingData)
    {
        var drawingType = drawingData?.DrawingType.ToString() ?? string.Empty;
        var isOverlay = drawingType.Equals("Overlay", StringComparison.OrdinalIgnoreCase);
        var isCustomer = drawingType.Equals("Customer", StringComparison.OrdinalIgnoreCase);
        var isPgb = run?.Wedge?.Subclass == WedgeSubclass.PGB;

        if (isPgb && isOverlay) return AnnotationCleanupProfile.PgbOverlay;
        if (isPgb) return AnnotationCleanupProfile.PgbProduction;
        if (isOverlay) return AnnotationCleanupProfile.CobLikeOverlay;
        if (isCustomer) return AnnotationCleanupProfile.CobLikeCustomer;
        return AnnotationCleanupProfile.CobLikeProduction;
    }
}
