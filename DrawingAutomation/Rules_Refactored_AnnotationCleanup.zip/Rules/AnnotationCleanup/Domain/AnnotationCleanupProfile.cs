namespace WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;

public enum AnnotationCleanupProfile
{
    CobLikeProduction,
    CobLikeCustomer,
    CobLikeOverlay,
    PgbProduction,
    PgbOverlay
}
