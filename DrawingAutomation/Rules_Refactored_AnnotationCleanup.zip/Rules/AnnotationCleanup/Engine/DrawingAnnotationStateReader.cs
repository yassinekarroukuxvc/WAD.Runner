using System;
using System.Collections.Generic;
using SolidWorks.Interop.sldworks;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;
using WAD.Runner.DrawingAutomation.Rules.Common;

namespace WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Engine;

public sealed class DrawingAnnotationStateReader
{
    public IReadOnlyDictionary<string, IReadOnlyCollection<string>> CollectExistingDisplayDimensionNames(
        ModelDoc2 drawingModel,
        AnnotationViewNameMap viewNames,
        bool activateEachView)
    {
        if (drawingModel is null) throw new ArgumentNullException(nameof(drawingModel));
        if (viewNames is null) throw new ArgumentNullException(nameof(viewNames));

        return AnnotationDeletionCore.CollectExistingDisplayDimensionFullNamesByView(
            drawingModel,
            viewNames.ToCore(),
            activateEachView);
    }
}
