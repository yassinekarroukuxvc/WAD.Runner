﻿using System;
using WAD.Runner.Application;
using WAD.Runner.DataManagement.Domain.Dimensions;
using WAD.Runner.DataManagement.Domain.Units;
using WAD.Runner.DataManagement.Domain.Wedge;

namespace WAD.Runner.ModelAutomation.Rules.Common;

/// <summary>
/// Shared, read-only access helper for WedgeData dimensions.
/// Keeps rule classes focused on business decisions instead of repeating
/// dictionary lookup, unit checking, and tolerance extraction code.
/// </summary>
public static class WedgeDimensionReader
{
    public static bool TryGetDimension(WedgeData wedge, string key, out Dimension dimension)
    {
        dimension = default!;

        if (wedge?.Dimensions is null || string.IsNullOrWhiteSpace(key))
            return false;

        if (!wedge.Dimensions.TryGetValue(DimensionKey.From(key), out var found) || found is null)
            return false;

        dimension = found;
        return true;
    }

    public static bool TryGetNominalValue(WedgeData wedge, string key, out decimal value)
    {
        value = 0m;

        if (!TryGetDimension(wedge, key, out var dimension))
            return false;

        value = dimension.Nominal.Value;
        return true;
    }

    public static bool HasPositiveNominal(WedgeData wedge, string key, decimal epsilon = 0m)
    {
        return TryGetNominalValue(wedge, key, out var value) && value > epsilon;
    }

    public static bool TryGetLengthNominalMm(
        WedgeData wedge,
        string key,
        out decimal nominalMm,
        string? logPrefix = null)
    {
        nominalMm = 0m;

        if (!TryGetDimension(wedge, key, out var dimension))
            return false;

        if (dimension.Nominal.Unit != UnitKind.Millimeter)
        {
            LogUnexpectedUnit(logPrefix, key, dimension.Nominal.Unit, UnitKind.Millimeter);
            return false;
        }

        nominalMm = dimension.Nominal.AsMm();
        return true;
    }

    public static bool TryGetAngleNominalDeg(
        WedgeData wedge,
        string key,
        out decimal nominalDeg,
        string? logPrefix = null)
    {
        nominalDeg = 0m;

        if (!TryGetDimension(wedge, key, out var dimension))
            return false;

        if (dimension.Nominal.Unit != UnitKind.Degree)
        {
            LogUnexpectedUnit(logPrefix, key, dimension.Nominal.Unit, UnitKind.Degree);
            return false;
        }

        nominalDeg = dimension.Nominal.AsDeg();
        return true;
    }

    public static bool TryGetLengthToleranceMm(
        WedgeData wedge,
        string key,
        out decimal lowerMm,
        out decimal upperMm,
        string? logPrefix = null)
    {
        lowerMm = 0m;
        upperMm = 0m;

        if (!TryGetDimension(wedge, key, out var dimension))
            return false;

        if (dimension.Nominal.Unit != UnitKind.Millimeter)
        {
            LogUnexpectedUnit(logPrefix, key, dimension.Nominal.Unit, UnitKind.Millimeter);
            return false;
        }

        lowerMm = dimension.Tol.Lower.Value;
        upperMm = dimension.Tol.Upper.Value;
        return true;
    }

    private static void LogUnexpectedUnit(
        string? logPrefix,
        string key,
        UnitKind actual,
        UnitKind expected)
    {
        if (string.IsNullOrWhiteSpace(logPrefix))
            return;

        Logger.Warn($"[{logPrefix}] '{key}' unit is {actual}; expected {expected}.");
    }
}
