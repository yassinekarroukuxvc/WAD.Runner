﻿using System;
using System.Collections.Generic;
using WAD.Runner.Application;
using WAD.Runner.DataManagement.Domain.Dimensions;
using WAD.Runner.DataManagement.Domain.Units;
using WAD.Runner.DataManagement.Domain.Wedge;

namespace WAD.Runner.ModelAutomation.Rules.CobLike;

/// <summary>
/// Shared equation normalization for COB / FP / UTUS.
/// This keeps derived dimensions and defaulting logic in one authoritative place.
/// </summary>
public abstract class CobLikeEquationInputNormalizerBase : IEquationInputNormalizer
{
    private const decimal DefaultVraDeg = 90m;

    private readonly string _logPrefix;

    protected CobLikeEquationInputNormalizerBase(string logPrefix)
    {
        _logPrefix = string.IsNullOrWhiteSpace(logPrefix) ? "CobLikeEquationInputNormalizer" : logPrefix;
    }

    public IReadOnlyDictionary<DimensionKey, Dimension> Normalize(WedgeData wedge, DrawingType drawingType)
    {
        if (wedge is null)
            throw new ArgumentNullException(nameof(wedge));

        var facts = new CobLikeRuleFacts(wedge);
        var result = new Dictionary<DimensionKey, Dimension>(wedge.Dimensions);

        ApplyVraDefaultRule(facts, result);

        var funnelGapMm = CobLikeGeometryCalculator.ComputeFunnelGapMmOrDefault(facts);
        UpsertLengthMm(result, "funnel_gap", funnelGapMm);

        Logger.Info($"[{_logPrefix}] funnel_gap = {funnelGapMm} mm");
        return result;
    }

    private void ApplyVraDefaultRule(CobLikeRuleFacts facts, IDictionary<DimensionKey, Dimension> result)
    {
        bool anyVPresent =
            (facts.TryGetNominalValue("VW", out var vw) && vw > 0m) ||
            (facts.TryGetNominalValue("VRR", out var vrr) && vrr > 0m) ||
            (facts.TryGetNominalValue("VR", out var vr) && vr > 0m);

        if (!anyVPresent)
            return;

        var vraKey = DimensionKey.From("VRA");
        bool hasVra = facts.Wedge.Dimensions.TryGetValue(vraKey, out var vraDim) && vraDim is not null;
        bool vraIsZero = hasVra && vraDim!.Nominal.Value == 0m;

        if (hasVra && !vraIsZero)
            return;

        UpsertAngleDeg(result, "VRA", DefaultVraDeg);
        Logger.Info($"[{_logPrefix}] Rule applied: (VW/VRR/VR > 0) and (VRA missing/0) -> VRA = 90deg");
    }

    private static void UpsertLengthMm(IDictionary<DimensionKey, Dimension> dims, string key, decimal mm)
    {
        var dk = DimensionKey.From(key);
        dims[dk] = Dimension.CreateLength(
            key: dk,
            nominalMm: Quantity.MmOf(mm),
            tolMm: Tolerance.Zero,
            comment: null);
    }

    private static void UpsertAngleDeg(IDictionary<DimensionKey, Dimension> dims, string key, decimal deg)
    {
        var dk = DimensionKey.From(key);
        dims[dk] = Dimension.CreateAngle(
            key: dk,
            nominalDeg: Quantity.DegOf(deg),
            comment: null);
    }
}
