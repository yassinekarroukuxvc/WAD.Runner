﻿using System;
using System.Collections.Generic;
using System.Linq;

using WAD.Runner.Application;
using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.ModelAutomation.Common;
using WAD.Runner.ModelAutomation.Core;
using WAD.Runner.ModelAutomation.Execution;
using WAD.Runner.ModelAutomation.Rules.Common;

namespace WAD.Runner.ModelAutomation.Rules._1001;

/// <summary>
/// Feature rules for the _1001 wedge type.
///
/// Type property: FG = Wed-Type; PGB = PGB-Type.
///     SW_STD    -> std_* feature family
///     SW_180REV -> rev_* feature family
///
/// PGB:
///     Feed-hole and foot-option features are suppressed.
///
/// FG:
///     Feed-hole property: Wed-Feed_H/Slot.
///     Foot-option property: Wed-Foot_Option.
///
/// PGB does not have a feed-hole or foot-option property.
/// PGB uses only PGB-Type when shank/type resolution is required.
///
/// CBR:
///     There is no separate CBR foot-option token.
///     A normal C foot becomes C+CBR when both CBRL and CBRD are > 0.
///
/// F foot:
///     STD -> std_fr_f_feature + std_br_f_feature ON,
///            FRO feature/sketch OFF.
///
///     REV -> rev_f_fr_feature + rev_f_br_feature ON,
///            FRO feature OFF.
///
///     F does not have a foot-option overlay sketch.
///
/// Overlay:
///     left_view  -> left cut/reference family
///     right_view -> right cut/reference family
///
/// W overlay:
///     When the VR/VW family is present, the standalone W overlay
///     sketch is suppressed and the VW case overlay sketch is used.
/// </summary>
public sealed class _1001FeatureRules : IFeatureRuleSet
{
    private static readonly FeatureFamily Std = new(
        AlwaysOn: new[]
        {
            "td_std_feature", "td_std_sketch",
            "isa_std_feature", "isa_std_sketch",
            "ba_std_feature", "ba_std_sketch",
            "nd_std_feature", "nd_std_sketch",
            "fro_std_feature", "fro_std_sketch"
        },
        Fro: new[]
        {
            "fro_std_feature",
            "fro_std_sketch"
        },
        Vr: new[]
        {
            "vr_std_feature",
            "vr_std_sketch"
        },
        Slb: new[]
        {
            "slb_std_feature",
            "slb_std_sketch"
        },
        W2: new[]
        {
            "w2_std_feature",
            "w2_std_sketch"
        },
        Ra2: new[]
        {
            "ra2_std_feature",
            "ra2_std_sketch"
        },
        Hole: new[]
        {
            "std_hole_feature",
            "std_hole_sketch",
            "std_hole_cut_feature",
            "std_hole_cut_sketch",
            "std_hole_combine"
        },
        Oval: new[]
        {
            "std_oval_plan",
            "std_oval_feature",
            "std_oval_sketch",
            "std_oval_cut_feature",
            "std_oval_cut_sketch",
            "std_oval_combine"
        },
        Slot: new[]
        {
            "std_slot_plan",
            "std_slot_feature",
            "std_slot_sketch",
            "std_slot_cut_feature",
            "std_slot_cut_sketch",
            "std_slot_combine"
        },
        CBase: new[]
        {
            "std_c_feature",
            "std_c_sketch"
        },
        CFr: "std_fr_c_feature",
        CBr: "std_br_c_feature",
        CCbr: "std_cbr_c_feature",
        Vg: new[]
        {
            "std_vg_feature",
            "std_vg_sketch",
            "std_fr_vg_feature",
            "std_br_vg_feature"
        },
        G: new[]
        {
            "std_g_feature",
            "std_g_sketch",
            "std_g_fr_feature",
            "std_g_br_feature"
        },
        F: new[]
        {
            "std_fr_f_feature",
            "std_br_f_feature"
        },
        RightCut: new[]
        {
            "std_ref_point_right",
            "std_right_cut_plan",
            "std_right_cut"
        },
        LeftCut: new[]
        {
            "std_ref_point_left",
            "std_left_cut_plan",
            "std_left_cut"
        },
        WPgbOverlay: "std_w_pgb_overlay_sketch",
        WFgOverlay: "std_w_fg_overlay_sketch",
        VwCases: new[]
        {
            "std_vw_case1_overlay_sketch",
            "std_vw_case2_overlay_sketch"
        },
        TCases: new[]
        {
            "std_t_case1_overlay_sketch",
            "std_t_case2_overlay_sketch",
            "std_t_case3_overlay_sketch",
            "std_t_case4_overlay_sketch"
        },
        FootOverlays: new[]
        {
            "std_c_overlay_sketch",
            "std_vg_overlay_sketch",
            "std_g_overlay_sketch"
        });

    private static readonly FeatureFamily Rev = new(
        AlwaysOn: new[]
        {
            "td_rev_feature",
            "td_rev_sketch",
            "isa_rev_feature",
            "isa_rev_sketch",
            "ba_rev_feature",
            "ba_rev_sketch",
            "nd_rev_feature",
            "erw_rev_sketch",
            "fro_rev_feature"
        },
        Fro: new[]
        {
            "fro_rev_feature"
        },
        Vr: new[]
        {
            "vr_rev_feature",
            "vr_rev_sketch"
        },
        Slb: new[]
        {
            "slb_rev_feature",
            "slb_rev_sketch"
        },
        W2: new[]
        {
            "w2_rev_feature",
            "w2_rev_sketch"
        },
        Ra2: new[]
        {
            "ra2_rev_feature",
            "ra2_rev_sketch"
        },
        Hole: new[]
        {
            "rev_hole_feature",
            "rev_hole_sketch",
            "rev_hole_cut_feature",
            "rev_hole_cut_sketch",
            "rev_hole_combine"
        },
        Oval: new[]
        {
            "rev_oval_plan",
            "rev_oval_feature",
            "rev_oval_sketch",
            "rev_oval_cut_feature",
            "rev_oval_cut_sketch",
            "rev_oval_combine_feature"
        },
        Slot: new[]
        {
            "rev_slot_plan",
            "rev_slot_feature",
            "rev_slot_sketch",
            "rev_slot_cut_feature",
            "rev_slot_cut_sketch",
            "rev_slot_combine_feature"
        },
        CBase: new[]
        {
            "rev_c_feature",
            "rev_c_sketch"
        },
        CFr: "rev_c_fr_feature",
        CBr: "rev_c_br_feature",
        CCbr: "rev_c_cbr_feature",
        Vg: new[]
        {
            "rev_vg_feature",
            "rev_vg_sketch",
            "rev_vg_fr_feature",
            "rev_vg_br_feature"
        },
        G: new[]
        {
            "rev_g_feature",
            "rev_g_sketch",
            "rev_g_fr_feature",
            "rev_g_br_feature"
        },
        F: new[]
        {
            "rev_f_fr_feature",
            "rev_f_br_feature"
        },
        RightCut: new[]
        {
            "rev_ref_point_right",
            "rev_right_cut_plan",
            "rev_right_cut"
        },
        LeftCut: new[]
        {
            "rev_ref_point_left",
            "rev_left_cut_plan",
            "rev_left_cut"
        },
        WPgbOverlay: "rev_w_pgb_overlay_sketch",
        WFgOverlay: "rev_w_fg_overlay_sketch",
        VwCases: new[]
        {
            "rev_vw_case1_overlay_sketch",
            "rev_vw_case2_overlay_sketch"
        },
        TCases: new[]
        {
            "rev_t_case1_overlay_sketch",
            "rev_t_case2_overlay_sketch",
            "rev_t_case3_overlay_sketch",
            "rev_t_case4_overlay_sketch"
        },
        FootOverlays: new[]
        {
            "rev_c_overlay_sketch",
            "rev_vg_overlay_sketch",
            "rev_g_overlay_sketch"
        });

    private static readonly string[] StdManaged = AllManaged(Std);
    private static readonly string[] RevManaged = AllManaged(Rev);

    public ModelRuleRunner.FeaturePlan Build(
        WedgeData wedge,
        FeatureRuleContext context)
    {
        if (wedge is null)
            throw new ArgumentNullException(nameof(wedge));

        if (context is null)
            throw new ArgumentNullException(nameof(context));

        var facts = new WedgeFacts(wedge, context.Subclass);
        var shank = ResolveShankType(facts);
        var active = shank == _1001ShankType.Std ? Std : Rev;

        var hasVr = HasAllPositive(facts, "VR", "VRR", "VW", "VRA");
        var hasOverlayVrFamily = HasAnyPositive(facts, "VR", "VRR", "VW");
        var hasSlb = HasAllPositive(facts, "VBL", "VBLR");
        var hasW2 = facts.HasPositive("W2");
        var hasRa2 = HasAllPositive(facts, "RA2", "RA2H");
        var hasOverlayVbl = facts.HasPositive("VBL");
        var hasOverlayRa2 = facts.HasPositive("RA2");

        var vwCase =
            ResolveOverlayVwCase(
                facts,
                hasOverlayVrFamily);

        var feedHole = context.Subclass == WedgeSubclass.FG
            ? ResolveFeedHoleType(facts)
            : FeedHoleType.NotApplicable;

        var footOption = context.Subclass == WedgeSubclass.FG
            ? ResolveFootOption(facts)
            : FootOptionType.NotApplicable;

        var hasCbr =
            footOption == FootOptionType.C &&
            HasAllPositive(
                facts,
                "CBRL",
                "CBRD");

        var plan = new FeaturePlanBuilder()
            .Know(StdManaged)
            .Know(RevManaged)
            .ForceSuppress(
                SwNames.EngravingFeature,
                SwNames.EngravingSketch)
            .ForceSuppress(
                shank == _1001ShankType.Std
                    ? RevManaged
                    : StdManaged);

        ApplyBaseRules(
            plan,
            active,
            hasVr,
            hasSlb,
            hasW2,
            hasRa2);

        ApplySubclassRules(
            plan,
            facts,
            active,
            context.Subclass,
            feedHole,
            footOption);

        if (context.DrawingType == DrawingType.Overlay)
        {
            ApplyOverlayRules(
                plan,
                context,
                active,
                footOption,
                hasOverlayVbl,
                hasOverlayRa2,
                hasOverlayVrFamily,
                vwCase);
        }
        else
        {
            plan.ForceSuppress(
                OverlayManaged(active));
        }

        Logger.Info(
            "[_1001FeatureRules] Build -> " +
            $"shank={shank}, " +
            $"subclass={context.Subclass}, " +
            $"drawingType={context.DrawingType}, " +
            $"targetConfig={context.TargetConfigurationName}, " +
            $"feedHole={feedHole}, " +
            $"footOption={footOption}, " +
            $"VR={hasVr}, " +
            $"overlay VR family={hasOverlayVrFamily}, " +
            $"CBR={hasCbr}, " +
            $"SLB={hasSlb}, " +
            $"W2={hasW2}, RA2={hasRa2}, " +
            $"VW case={vwCase}.");

        return plan.Build();
    }

    private static void ApplyBaseRules(
        FeaturePlanBuilder plan,
        FeatureFamily family,
        bool hasVr,
        bool hasSlb,
        bool hasW2,
        bool hasRa2)
    {
        plan.Activate(
            family.AlwaysOn);

        if (hasVr)
            plan.Activate(family.Vr);

        if (hasSlb)
            plan.Activate(family.Slb);

        if (hasW2)
            plan.Activate(family.W2);

        if (hasRa2)
            plan.Activate(family.Ra2);
    }

    private static void ApplySubclassRules(
        FeaturePlanBuilder plan,
        WedgeFacts facts,
        FeatureFamily family,
        WedgeSubclass subclass,
        FeedHoleType feedHole,
        FootOptionType footOption)
    {
        var feedManaged =
            FeedHoleManaged(family);

        var footManaged =
            FootManaged(family);

        plan.Deactivate(
            feedManaged);

        plan.Deactivate(
            footManaged);

        if (subclass == WedgeSubclass.PGB)
        {
            plan.ForceSuppress(
                feedManaged);

            plan.ForceSuppress(
                footManaged);

            // PGB does not use FRO.
            // This suppresses the correct STD/REV FRO family automatically.
            plan.ForceSuppress(
                family.Fro);

            return;
        }

        switch (feedHole)
        {
            case FeedHoleType.Std:
                plan.Activate(
                    family.Hole);
                break;

            case FeedHoleType.Oval:
                plan.Activate(
                    family.Oval);
                break;

            case FeedHoleType.Slot:
                plan.Activate(
                    family.Slot);
                break;

            default:
                throw new InvalidOperationException(
                    "Unable to resolve the _1001 feed-hole type for an FG wedge. " +
                    $"Expected STD, Oval or Slot in '{facts.EffectivePropertyName("Wed-Feed_H/Slot")}'.");
        }

        ApplyFootRules(
            plan,
            facts,
            family,
            footOption);
    }

    private static void ApplyFootRules(
        FeaturePlanBuilder plan,
        WedgeFacts facts,
        FeatureFamily family,
        FootOptionType footOption)
    {
        switch (footOption)
        {
            case FootOptionType.C:
                ApplyCFootRules(
                    plan,
                    facts,
                    family);
                break;

            case FootOptionType.Vg:
                plan.Activate(
                    family.Vg);
                break;

            case FootOptionType.G:
                plan.Activate(
                    family.G);
                break;

            case FootOptionType.F:
                plan.Activate(
                    family.F);

                plan.ForceSuppress(
                    family.Fro);
                break;

            case FootOptionType.Cc:
                break;

            default:
                throw new InvalidOperationException(
                    "Unable to resolve the _1001 foot option for an FG wedge. " +
                    "Expected LW_/SW_ C, VG, G, F or CC.");
        }
    }

    private static void ApplyCFootRules(
        FeaturePlanBuilder plan,
        WedgeFacts facts,
        FeatureFamily family)
    {
        var froEqualsFr =
            ResolveFroEqualsFr(
                facts);

        var hasCbrl =
            facts.HasPositive(
                "CBRL");

        var hasCbrd =
            facts.HasPositive(
                "CBRD");

        /*
         * There is no C-with-CBR foot option.
         *
         * CBR is inferred only from the dimensions.
         * Both values must be present together.
         */
        if (hasCbrl != hasCbrd)
        {
            throw new InvalidOperationException(
                "_1001 C foot has incomplete CBR dimensions. " +
                "CBRL and CBRD must either both be > 0 or both be absent/zero.");
        }

        var hasCbr =
            hasCbrl &&
            hasCbrd;

        plan.Activate(
            family.CBase);

        if (hasCbr)
        {
            /*
             * C + CBRL > 0 + CBRD > 0
             *
             * Use the CBR back-radius feature instead of
             * the normal C back-radius feature.
             */
            plan.Activate(
                family.CCbr);

            plan.ForceSuppress(
                family.CBr);

            if (!froEqualsFr)
            {
                plan.Activate(
                    family.CFr);
            }

            return;
        }

        /*
         * Normal C foot without CBR.
         */
        plan.Activate(
            family.CBr);

        plan.ForceSuppress(
            family.CCbr);

        if (!froEqualsFr)
        {
            plan.Activate(
                family.CFr);
        }
    }

    private static void ApplyOverlayRules(
        FeaturePlanBuilder plan,
        FeatureRuleContext context,
        FeatureFamily family,
        FootOptionType footOption,
        bool hasVbl,
        bool hasRa2,
        bool hasOverlayVrFamily,
        OverlayVwCase vwCase)
    {
        plan.Deactivate(
            OverlayManaged(family));

        ApplyOverlayCutRule(
            plan,
            context,
            family);

        /*
         * W overlay behavior:
         *
         * No VR/VW family:
         *     -> use the standalone W overlay sketch.
         *
         * VR/VW family:
         *     -> suppress the standalone W sketch and use
         *        the VW case1/case2 overlay sketch instead.
         */
        var selectedWOverlay =
            context.Subclass == WedgeSubclass.PGB
                ? family.WPgbOverlay
                : family.WFgOverlay;

        var otherWOverlay =
            context.Subclass == WedgeSubclass.PGB
                ? family.WFgOverlay
                : family.WPgbOverlay;

        plan.ForceSuppress(
            otherWOverlay);

        if (hasOverlayVrFamily)
        {
            plan.ForceSuppress(
                selectedWOverlay);
        }
        else
        {
            plan.Activate(
                selectedWOverlay);
        }

        if (vwCase != OverlayVwCase.None)
        {
            plan.ActivateOnly(
                vwCase == OverlayVwCase.Case1
                    ? family.VwCases[0]
                    : family.VwCases[1],
                family.VwCases);
        }
        else
        {
            plan.ForceSuppress(
                family.VwCases);
        }

        var tSketch =
            hasVbl
                ? hasRa2
                    ? family.TCases[3]
                    : family.TCases[1]
                : hasRa2
                    ? family.TCases[2]
                    : family.TCases[0];

        plan.ActivateOnly(
            tSketch,
            family.TCases);

        if (context.Subclass == WedgeSubclass.PGB)
        {
            plan.ForceSuppress(
                family.FootOverlays);

            Logger.Info(
                "[_1001FeatureRules] PGB overlay -> " +
                $"W overlay={!hasOverlayVrFamily}, " +
                $"VR/VW family={hasOverlayVrFamily}, " +
                $"VW case={vwCase}.");

            return;
        }

        var footSketch =
            footOption switch
            {
                /*
                 * Normal C and C with CBR both use the
                 * same C foot overlay sketch.
                 *
                 * C with CBR is inferred from CBRL/CBRD,
                 * not from a separate foot-option token.
                 */
                FootOptionType.C =>
                    family.FootOverlays[0],

                FootOptionType.Vg =>
                    family.FootOverlays[1],

                FootOptionType.G =>
                    family.FootOverlays[2],

                /*
                 * F has no foot-option overlay sketch.
                 */
                FootOptionType.F =>
                    null,

                _ =>
                    null
            };

        if (footSketch is not null)
        {
            plan.ActivateOnly(
                footSketch,
                family.FootOverlays);
        }
        else
        {
            plan.ForceSuppress(
                family.FootOverlays);
        }

        Logger.Info(
            "[_1001FeatureRules] FG overlay -> " +
            $"W overlay={!hasOverlayVrFamily}, " +
            $"VR/VW family={hasOverlayVrFamily}, " +
            $"VW case={vwCase}.");
    }

    private static void ApplyOverlayCutRule(
        FeaturePlanBuilder plan,
        FeatureRuleContext context,
        FeatureFamily family)
    {
        var view =
            NormalizePackedToken(
                context.TargetConfigurationName);

        switch (view)
        {
            case "LEFT_VIEW":
                plan.Activate(
                    family.LeftCut);

                plan.ForceSuppress(
                    family.RightCut);
                break;

            case "RIGHT_VIEW":
                plan.Activate(
                    family.RightCut);

                plan.ForceSuppress(
                    family.LeftCut);
                break;

            default:
                plan.ForceSuppress(
                    family.LeftCut);

                plan.ForceSuppress(
                    family.RightCut);
                break;
        }
    }

    private static _1001ShankType ResolveShankType(
        WedgeFacts facts)
    {
        var token =
            NormalizePackedToken(
                facts.NormalizedSubclassPropertyToken(
                    "PGB-Type",
                "Wed-Type",
                    "Wed_Type",
                    "Wed Type",
                    "Wedge-Type",
                    "Wedge_Type",
                    "wedge_type"));

        return token switch
        {
            "SW_STD" or
            "STD" =>
                _1001ShankType.Std,

            "SW_180REV" or
            "SW_180_REV" or
            "180REV" or
            "180_REV" =>
                _1001ShankType.Rev,

            _ =>
                throw new InvalidOperationException(
                    $"Unable to resolve the _1001 shank from '{facts.EffectivePropertyName("Wed-Type")}'. " +
                    "Expected SW_STD or SW_180REV, but received " +
                    $"'{DisplayToken(token)}'.")
        };
    }

    private static FeedHoleType ResolveFeedHoleType(
        WedgeFacts facts)
    {
        var raw =
            facts.NormalizedPropertyToken(
                "Wed-Feed_H/Slot",
                "Wed_Feed_H_Slot",
                "Wed Feed H Slot",
                "Wed-Feed H Slot",
                "Feed_H/Slot",
                "Feed_H_Slot",
                "Feed H Slot",
                "feed_h_slot");

        var token =
            NormalizeFeedHoleToken(
                raw);

        return token switch
        {
            "STD" =>
                FeedHoleType.Std,

            "OVAL" =>
                FeedHoleType.Oval,

            "SLOT" =>
                FeedHoleType.Slot,

            _ =>
                FeedHoleType.Unknown
        };
    }

    private static FootOptionType ResolveFootOption(
        WedgeFacts facts)
    {
        var token =
            NormalizePackedToken(
                facts.NormalizedPropertyToken(
                    "Wed-Foot_Option",
                    "Wed_Foot_Option",
                    "Wed Foot Option",
                "Wed-Foot Option",
                    "Foot_Option",
                    "Foot Option",
                    "foot_option"));

        /*
         * IMPORTANT:
         *
         * There is no LW_C_CBR / SW_C_CBR.
         *
         * C with CBR still comes from LW_C / SW_C / C.
         * CBRL and CBRD decide whether CBR geometry is used.
         */
        return token switch
        {
            "LW_C" or
            "SW_C" or
            "C" =>
                FootOptionType.C,

            "LW_VG" or
            "SW_VG" or
            "VG" =>
                FootOptionType.Vg,

            "LW_G" or
            "SW_G" or
            "G" =>
                FootOptionType.G,

            "LW_F" or
            "SW_F" or
            "F" =>
                FootOptionType.F,

            "LW_CC" or
            "SW_CC" or
            "CC" =>
                FootOptionType.Cc,

            _ =>
                FootOptionType.Unknown
        };
    }

    private static OverlayVwCase ResolveOverlayVwCase(
        WedgeFacts facts,
        bool hasOverlayVrFamily)
    {
        if (!hasOverlayVrFamily ||
            !facts.TryGetLengthMm(
                "VW",
                out var vw) ||
            vw <= WedgeFacts.DefaultPositiveEpsilon)
        {
            return OverlayVwCase.None;
        }

        if (!facts.TryGetLengthMm(
                "W",
                out var w))
        {
            Logger.Warn(
                "[_1001FeatureRules] VW is present but W is missing/not a length. " +
                "No VW overlay case selected.");

            return OverlayVwCase.None;
        }

        return decimal.Abs(
                   vw -
                   w) <=
               WedgeFacts.DefaultPositiveEpsilon
            ? OverlayVwCase.Case1
            : OverlayVwCase.Case2;
    }

    private static bool ResolveFroEqualsFr(
        WedgeFacts facts)
    {
        if (!facts.TryGetLengthMm(
                "FRO",
                out var fro))
        {
            throw new InvalidOperationException(
                "Cannot apply _1001 C-foot rules because FRO is missing/not a length.");
        }

        if (!facts.TryGetLengthMm(
                "FR",
                out var fr))
        {
            throw new InvalidOperationException(
                "Cannot apply _1001 C-foot rules because FR is missing/not a length.");
        }

        return decimal.Abs(
                   fro -
                   fr) <=
               WedgeFacts.DefaultPositiveEpsilon;
    }

    private static bool HasAllPositive(
        WedgeFacts facts,
        params string[] keys)
        => keys.All(
            key => facts.HasPositive(key));

    private static bool HasAnyPositive(
        WedgeFacts facts,
        params string[] keys)
        => keys.Any(
            key => facts.HasPositive(key));

    private static string NormalizeFeedHoleToken(
        string? raw)
    {
        var token =
            RemovePackedDatabaseSuffix(raw)
                .Trim()
                .ToUpperInvariant();

        if (token.StartsWith(
                "STD",
                StringComparison.OrdinalIgnoreCase) ||
            token.StartsWith(
                "STANDARD",
                StringComparison.OrdinalIgnoreCase))
        {
            return "STD";
        }

        if (token.StartsWith(
                "OVAL",
                StringComparison.OrdinalIgnoreCase))
        {
            return "OVAL";
        }

        if (token.StartsWith(
                "SLOT",
                StringComparison.OrdinalIgnoreCase))
        {
            return "SLOT";
        }

        return token;
    }

    private static string NormalizePackedToken(
        string? raw)
    {
        var token =
            RemovePackedDatabaseSuffix(raw)
                .Trim()
                .Replace('-', '_')
                .Replace(' ', '_')
                .Trim('_')
                .ToUpperInvariant();

        while (token.Contains(
                   "__",
                   StringComparison.Ordinal))
        {
            token =
                token.Replace(
                    "__",
                    "_",
                    StringComparison.Ordinal);
        }

        return token;
    }

    private static string RemovePackedDatabaseSuffix(
        string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return string.Empty;

        var token =
            raw
                .Trim()
                .Trim('\0');

        var separatorIndex =
            token.IndexOf(';');

        return separatorIndex >= 0
            ? token[..separatorIndex]
            : token;
    }

    private static string DisplayToken(
        string token)
        => string.IsNullOrWhiteSpace(token)
            ? "<missing>"
            : token;

    private static string[] FeedHoleManaged(
        FeatureFamily family)
        => family.Hole
            .Concat(family.Oval)
            .Concat(family.Slot)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

    private static string[] FootManaged(
        FeatureFamily family)
        => family.CBase
            .Concat(
                new[]
                {
                    family.CFr,
                    family.CBr,
                    family.CCbr
                })
            .Concat(family.Vg)
            .Concat(family.G)
            .Concat(family.F)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

    private static string[] OverlayManaged(
        FeatureFamily family)
        => family.RightCut
            .Concat(family.LeftCut)
            .Concat(
                new[]
                {
                    family.WPgbOverlay,
                    family.WFgOverlay
                })
            .Concat(family.VwCases)
            .Concat(family.TCases)
            .Concat(family.FootOverlays)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

    private static string[] AllManaged(
        FeatureFamily family)
        => family.AlwaysOn
            .Concat(family.Fro)
            .Concat(family.Vr)
            .Concat(family.Slb)
            .Concat(family.W2)
            .Concat(family.Ra2)
            .Concat(FeedHoleManaged(family))
            .Concat(FootManaged(family))
            .Concat(OverlayManaged(family))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

    private sealed record FeatureFamily(
        string[] AlwaysOn,
        string[] Fro,
        string[] Vr,
        string[] Slb,
        string[] W2,
        string[] Ra2,
        string[] Hole,
        string[] Oval,
        string[] Slot,
        string[] CBase,
        string CFr,
        string CBr,
        string CCbr,
        string[] Vg,
        string[] G,
        string[] F,
        string[] RightCut,
        string[] LeftCut,
        string WPgbOverlay,
        string WFgOverlay,
        string[] VwCases,
        string[] TCases,
        string[] FootOverlays);

    private enum _1001ShankType
    {
        Std,
        Rev
    }

    private enum FeedHoleType
    {
        NotApplicable,
        Unknown,
        Std,
        Oval,
        Slot
    }

    private enum FootOptionType
    {
        NotApplicable,
        Unknown,
        C,
        Vg,
        G,
        F,
        Cc
    }

    private enum OverlayVwCase
    {
        None,
        Case1,
        Case2
    }
}