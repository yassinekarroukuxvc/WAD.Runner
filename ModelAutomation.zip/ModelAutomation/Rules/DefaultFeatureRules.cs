﻿using System;
using System.Collections.Generic;

using WAD.Runner.Application;
using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.ModelAutomation.Common;
using WAD.Runner.ModelAutomation.Execution;

namespace WAD.Runner.ModelAutomation.Rules;

/// <summary>
/// Fallback feature rules for unknown wedge types.
/// Production/Customer keeps engraving enabled; Overlay leaves template state unchanged.
/// </summary>
public sealed class DefaultFeatureRules : IFeatureRuleSet
{
    public ModelRuleRunner.FeaturePlan Build(WedgeData wedge, FeatureRuleContext context)
    {
        if (wedge is null) throw new ArgumentNullException(nameof(wedge));
        if (context is null) throw new ArgumentNullException(nameof(context));

        var suppress = new List<string>();
        var unsuppress = new List<string>();

        Logger.Info($"[DefaultFeatureRules] Build -> subclass={context.Subclass}, drawingType={context.DrawingType}");

        if (context.DrawingType is DrawingType.Production or DrawingType.Customer)
        {
            unsuppress.Add(SwNames.Engraving);
            Logger.Info($"[DefaultFeatureRules] Non-overlay -> unsuppress engraving '{SwNames.Engraving}'");
        }
        else
        {
            Logger.Info("[DefaultFeatureRules] Overlay -> no toggles; keep template state.");
        }

        return new ModelRuleRunner.FeaturePlan(suppress, unsuppress);
    }
}
