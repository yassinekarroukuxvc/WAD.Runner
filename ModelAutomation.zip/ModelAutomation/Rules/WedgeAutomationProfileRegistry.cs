﻿using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.ModelAutomation.Rules.CKVD;
using WAD.Runner.ModelAutomation.Rules.COB;
using WAD.Runner.ModelAutomation.Rules.FP;
using WAD.Runner.ModelAutomation.Rules.OSG7;
using WAD.Runner.ModelAutomation.Rules.UTUS;
using WAD.Runner.ModelAutomation.Tolerances;

namespace WAD.Runner.ModelAutomation.Rules;

/// <summary>
/// Single source of truth for wedge-type to rule-set mapping.
/// Rule objects are intentionally cached: they are stateless planners, so recreating
/// them for every model job only adds noise and makes dependency flow harder to trace.
/// </summary>
public static class WedgeAutomationProfileRegistry
{
    private static readonly WedgeAutomationProfile DefaultProfile = new(
        ConfigurationRules: new DefaultConfigurationRules(),
        FeatureRules: new DefaultFeatureRules(),
        EquationNormalizer: new NoOpEquationInputNormalizer(),
        ToleranceRules: new NoOpToleranceRules());

    private static readonly WedgeAutomationProfile CkvdProfile = new(
        ConfigurationRules: new CkvdConfigurationRules(),
        FeatureRules: new CkvdFeatureRules(),
        EquationNormalizer: new NoOpEquationInputNormalizer(),
        ToleranceRules: new CkvdToleranceRules());

    private static readonly WedgeAutomationProfile CobProfile = new(
        ConfigurationRules: new CobConfigurationRules(),
        FeatureRules: new CobFeatureRules(),
        EquationNormalizer: new CobEquationInputNormalizer(),
        ToleranceRules: new CobToleranceRules());

    private static readonly WedgeAutomationProfile UtusProfile = new(
        ConfigurationRules: new UtusConfigurationRules(),
        FeatureRules: new UtusFeatureRules(),
        EquationNormalizer: new UtusEquationInputNormalizer(),
        ToleranceRules: new UtusToleranceRules());

    private static readonly WedgeAutomationProfile FpProfile = new(
        ConfigurationRules: new FpConfigurationRules(),
        FeatureRules: new FpFeatureRules(),
        EquationNormalizer: new FpEquationInputNormalizer(),
        ToleranceRules: new FpToleranceRules());

    private static readonly WedgeAutomationProfile Osg7Profile = new(
        ConfigurationRules: new DefaultConfigurationRules(),
        FeatureRules: new Osg7FeatureRules(),
        EquationNormalizer: new Osg7EquationInputNormalizer(),
        ToleranceRules: new Osg7ToleranceRules());

    public static WedgeAutomationProfile For(WedgeType wedgeType)
        => wedgeType switch
        {
            WedgeType.CKVD => CkvdProfile,
            WedgeType.COB => CobProfile,
            WedgeType.UTUS => UtusProfile,
            WedgeType.FP => FpProfile,
            WedgeType.OSG7 => Osg7Profile,
            _ => DefaultProfile
        };
}
