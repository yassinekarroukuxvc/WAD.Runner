using System;
using System.Collections.Generic;

using WAD.Runner.DataManagement.Domain.Wedge;
using WAD.Runner.DrawingAutomation.Overlay.Positioning;
using WAD.Runner.DrawingAutomation.Profiles;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Catalogs;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Resolution;
using WAD.Runner.DrawingAutomation.Wedges.ABT.Annotations;

namespace WAD.Runner.DrawingAutomation.Wedges.ABT;

public sealed class AbtDrawingModule : IDrawingWedgeModule
{
    /*
     * Overlay candidate dimensions.
     *
     * This contains every FG Overlay dimension marked "X" for ABT in
     * Prod_style_Rev.03, plus the existing overlay/PGB keys that must remain
     * available to the overlay pipeline.
     *
     * The final FG table content is controlled by FgOverlayTableKeys.
     */
    private static readonly IReadOnlyList<string> OverlayDimensionKeyList =
        Array.AsReadOnly(new[]
        {
            "B", "BA", "BF", "BR", "CA", "CBL", "CBRA",
            "CBRD", "CBRL", "CD", "CGD", "CGO", "CGR", "CL",
            "ERD", "ERL", "ERW", "F", "FA", "FD", "FL",
            "FLC", "FLER", "FLG", "FNA", "FNH", "FNO", "FR",
            "FRO", "FX", "GA", "GD", "GO", "GR", "H",
            "HA", "ISA", "MB", "MFL", "MI", "MTA", "RA",
            "RC", "T", "T1", "TD", "TDF", "TL", "VBL",
            "VBLR", "VFL", "VFLR", "VR", "VRA", "VRR", "VW",
            "W", "Y", "C", "HH", "G", "RA2"
        });

    private static readonly ViewNames ProductionCustomerViews = new(
        Front: "Drawing View2",
        Side: "Drawing View1",
        Top: "Drawing View3",
        Detail: "Drawing View4",
        Section: "Section View AC-AC");

    private static readonly ViewNames OverlayViews = new(
        Front: "Drawing View5",
        Side: "Drawing View4",
        Top: "Drawing View3",
        Detail: "Drawing View1",
        Section: "Drawing View2");

    // Customer and Production MUST be separate for ABT: the Excel X marks differ.
    private static readonly IReadOnlySet<string> FgCustomerDrawingTableKeys = Keys(
        "B", "BA", "BF", "BR", "CD", "CGD", "CGO",
        "CGR", "CL", "F", "FA", "FD", "FL", "FNA",
        "FR", "GA", "GD", "GO", "GR", "H", "HA",
        "ISA", "RA", "T", "T1", "TD", "TDF", "TL",
        "VBL", "VBLR", "VFL", "VFLR", "VR", "VRA", "VRR",
        "VW", "W", "Y");

    private static readonly IReadOnlySet<string> FgProductionDrawingTableKeys = Keys(
        "B","BF", "BR","CBL",
        "CBRD", "CBRL", "CD", "CGD", "CGO", "CGR", "CL",
        "ERD", "ERL", "ERW", "F", "FD", "FL",
        "FLC", "FLER", "FLG", "FNO", "FR",
        "FRO", "FX", "GD", "GO", "GR", "H",
        "RC", "T", "T1", "TD", "TDF", "TL", "VBL",
        "VBLR", "VFL", "VFLR", "VR", "VRR", "VW",
        "W", "Y");

    private static readonly IReadOnlySet<string> FgOverlayTableKeys = Keys(
        "B", "BF", "BR", "CBL", 
        "CBRD", "CBRL", "CD", "CGD", "CGO", "CGR", "CL",
        "ERD", "ERL", "ERW", "F","FD", "FL",
        "FLC", "FLER", "FLG", "FNO", "FR",
        "FRO", "FX", "GD", "GO", "GR", "H",
        "RC", "T", "T1", "TD", "TDF", "TL", "VBL",
        "VBLR", "VFL", "VFLR", "VR", "VRA", "VRR", "VW",
        "W", "Y");

    private static readonly IReadOnlySet<string> PgbProductionTableKeys = Keys(
        "TD", "TDF", "W", "ISA", "VW", "VR", "VRA",
        "TL", "BA", "T", "FL", "VBL");

    private static readonly IReadOnlySet<string> PgbOverlayTableKeys = Keys(
        "TD", "TDF", "W", "ISA", "VW", "VR", "VRA",
        "TL", "BA", "T", "FL", "VBL");

    public AbtDrawingModule()
    {
        Profiles = Array.AsReadOnly(new[]
        {
            DrawingProfileFactory.Create(WedgeType, WedgeSubclass.FG, DrawingType.Production, "ABT FG Production", ProductionCustomerViews, new[] { "SHEET1" }, DrawingViewNames.SecondaryBreaklineViews),
            DrawingProfileFactory.Create(WedgeType, WedgeSubclass.FG, DrawingType.Customer, "ABT FG Customer", ProductionCustomerViews, new[] { "SHEET1" }, DrawingViewNames.SecondaryBreaklineViews),
            DrawingProfileFactory.Create(WedgeType, WedgeSubclass.FG, DrawingType.Overlay, "ABT FG Overlay", OverlayViews, new[] { "OVERLAY" }, DrawingViewNames.NoBreaklineViews),
            DrawingProfileFactory.Create(WedgeType, WedgeSubclass.PGB, DrawingType.Production, "ABT PGB Production", ProductionCustomerViews, new[] { "SHEET1" }, DrawingViewNames.SecondaryBreaklineViews),
            DrawingProfileFactory.Create(WedgeType, WedgeSubclass.PGB, DrawingType.Customer, "ABT PGB Customer", ProductionCustomerViews, new[] { "SHEET1" }, DrawingViewNames.SecondaryBreaklineViews),
            DrawingProfileFactory.Create(WedgeType, WedgeSubclass.PGB, DrawingType.Overlay, "ABT PGB Overlay", OverlayViews, new[] { "OVERLAY" }, DrawingViewNames.NoBreaklineViews)
        });
    }

    public WedgeType WedgeType =>
        global::WAD.Runner.DataManagement.Domain.Wedge.WedgeType.ABT;

    public DrawingWedgeBehavior Behavior { get; } = new(
        OverlayMagnificationSourceKey: "T",
        OverlayDimensionKeys: OverlayDimensionKeyList,
        OverlayReferencePointSketch: "std_ref_point_right",
        RepositionPrimaryOverlayViews: false,
        DeleteFrontOverlayViewWhenVrIsZero: false,
        HideVrExtremaWhenOverlayCompressed: false,
        BreaklineTlOverrideMm: 20.0m);

    public IReadOnlyList<DrawingProfile> Profiles { get; }

    public IOverlayViewPositioningRule OverlayPositioningRule { get; } =
        new AbtOverlayViewPositioningRule();

    public IReadOnlyList<IAnnotationRuleCatalog> AnnotationCatalogs { get; } =
        Array.AsReadOnly<IAnnotationRuleCatalog>(
            new IAnnotationRuleCatalog[]
            {
                new AbtFgProductionAnnotationRules(),
                new AbtFgCustomerAnnotationRules(),
                new AbtFgOverlayAnnotationRules(),
                new AbtPgbProductionAnnotationRules(),
                new AbtPgbOverlayAnnotationRules()
            });

    public IAnnotationWedgeContextResolver AnnotationContextResolver { get; } =
        new AbtAnnotationContextResolver();

    public AnnotationCleanupProfile ResolveAnnotationProfile(
        WedgeSubclass subclass,
        DrawingType drawingType)
    {
        if (subclass == WedgeSubclass.PGB)
        {
            return drawingType == DrawingType.Overlay
                ? AnnotationCleanupProfile.AbtPgbOverlay
                : AnnotationCleanupProfile.AbtPgbProduction;
        }

        return drawingType switch
        {
            DrawingType.Overlay =>
                AnnotationCleanupProfile.AbtFgOverlay,

            DrawingType.Customer =>
                AnnotationCleanupProfile.AbtFgCustomer,

            _ =>
                AnnotationCleanupProfile.AbtFgProduction
        };
    }

    public string? ResolveReferencedConfiguration(
        string logicalView,
        WedgeSubclass subclass,
        DrawingType drawingType,
        bool hasVw,
        bool hasVr)
    {
        if (drawingType is DrawingType.Production or DrawingType.Customer)
            return "Default";

        if (drawingType != DrawingType.Overlay)
            return null;

        if (IsView(logicalView, DrawingViewNames.Detail))
            return "right_view";

        if (IsView(logicalView, DrawingViewNames.Section))
            return "left_view";

        return "Default";
    }

    public IReadOnlySet<string>? GetAllowedDimensionTableKeys(
        WedgeSubclass subclass,
        DrawingType drawingType)
        => (subclass, drawingType) switch
        {
            (WedgeSubclass.FG, DrawingType.Production) =>
                FgProductionDrawingTableKeys,

            (WedgeSubclass.FG, DrawingType.Customer) =>
                FgCustomerDrawingTableKeys,

            (WedgeSubclass.FG, DrawingType.Overlay) =>
                FgOverlayTableKeys,

            (WedgeSubclass.PGB, DrawingType.Production) =>
                PgbProductionTableKeys,

            (WedgeSubclass.PGB, DrawingType.Customer) =>
                PgbProductionTableKeys,

            (WedgeSubclass.PGB, DrawingType.Overlay) =>
                PgbOverlayTableKeys,

            _ => null
        };

    private static bool IsView(
        string logicalView,
        string expected)
        => string.Equals(
            logicalView?.Trim(),
            expected,
            StringComparison.OrdinalIgnoreCase);

    private static IReadOnlySet<string> Keys(
        params string[] values)
        => new HashSet<string>(
            values,
            StringComparer.OrdinalIgnoreCase);
}
