﻿using System;
using System.Collections.Generic;

using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Catalogs;
using WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain;

using static WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Conditions.AnnotationConditions;
using static WAD.Runner.DrawingAutomation.Rules.AnnotationCleanup.Domain.AnnotationView;

namespace WAD.Runner.DrawingAutomation.Wedges.Fp.Annotations;

public abstract class FpAnnotationRuleCatalogBase : AnnotationRuleCatalogBase
{
    private const string AnnotationTopPlan = "annotation_top_plan";
    private const string AnnotationTopPlanTemplateTypo = "annoation_top_plan";
    private const string AnnotationRightPlan = "annotation_right_plan";
    private const string AnnotationStdFrontPlan = "annotation_std_front_plan";
    private const string AnnotationRevFrontPlan = "annotation_rev_front_plan";
    private const string AnnotationFrontPlan = "annotation_front_plan";
    private const string AnnotationRevPlan = "annotation_rev_plan";

    protected IReadOnlyList<AnnotationKeepRule> BuildPgbProductionCustomerRules(string idPrefix)
    {
        var isStd = ShankIs(FpAnnotationShankTypes.Std);
        var isRev = ShankIs(FpAnnotationShankTypes.Rev);
        var hasVbl = DimPositive("VBL");
        var noVbl = Not(hasVbl);

        return new List<AnnotationKeepRule>
        {
            Keep($"{idPrefix}-SIDE-STD-BA", Side, $"BA@{AnnotationStdFrontPlan}", All(isStd, noVbl), "FP PGB STD Side keeps BA when VBL is not positive."),
            Keep($"{idPrefix}-SIDE-STD-VBL", Side, $"VBL@{AnnotationStdFrontPlan}", All(isStd, hasVbl), "FP PGB STD Side keeps VBL when VBL is positive."),
            Keep($"{idPrefix}-SIDE-STD-BA-SLB", Side, $"BA_SLB@{AnnotationStdFrontPlan}", All(isStd, hasVbl), "FP PGB STD Side keeps BA_SLB when VBL is positive."),
            Keep($"{idPrefix}-SIDE-REV-BA", Side, $"BA@{AnnotationRevFrontPlan}", All(isRev, noVbl), "FP PGB REV Side keeps BA when VBL is not positive."),
            Keep($"{idPrefix}-SIDE-REV-VBL", Side, $"VBL@{AnnotationRevFrontPlan}", All(isRev, hasVbl), "FP PGB REV Side keeps VBL when VBL is positive."),
            Keep($"{idPrefix}-SIDE-REV-BA-SLB", Side, $"BA_SLB@{AnnotationRevFrontPlan}", All(isRev, hasVbl), "FP PGB REV Side keeps BA_SLB when VBL is positive."),

            Keep($"{idPrefix}-FRONT-TL", Front, $"TL@{AnnotationRightPlan}", Always(), "FP PGB Front always keeps TL."),
            Keep($"{idPrefix}-FRONT-VR", Front, $"VR@{AnnotationRightPlan}", DimPositive("VR"), "FP PGB Front keeps VR when VR is positive."),

            KeepWithAliases($"{idPrefix}-TOP-TD", Top, $"TD@{AnnotationTopPlan}", new[] { $"TD@{AnnotationTopPlanTemplateTypo}" }, Always(), "FP PGB Top always keeps TD."),
            KeepWithAliases($"{idPrefix}-TOP-TDF-STD", Top, $"TDF_STD@{AnnotationTopPlan}", new[] { $"TDF_STD@{AnnotationTopPlanTemplateTypo}" }, isStd, "FP PGB Top keeps TDF_STD for SW_STD."),
            KeepWithAliases($"{idPrefix}-TOP-TDF-REV", Top, $"TDF_REV@{AnnotationTopPlan}", new[] { $"TDF_REV@{AnnotationTopPlanTemplateTypo}" }, isRev, "FP PGB Top keeps TDF_REV for SW_180REV."),

            Keep($"{idPrefix}-DETAIL-W", Detail, $"W_NOM@{AnnotationRightPlan}", Always(), "FP PGB Detail always keeps W."),
            Keep($"{idPrefix}-DETAIL-ISA", Detail, $"ISA@{AnnotationRightPlan}", Always(), "FP PGB Detail always keeps ISA."),
            Keep($"{idPrefix}-DETAIL-VW", Detail, $"VW@{AnnotationRightPlan}", DimPositive("VW"), "FP PGB Detail keeps VW when VW is positive."),
            Keep($"{idPrefix}-DETAIL-VRA", Detail, $"VRA@{AnnotationRightPlan}", DimPositive("VR"), "FP PGB Detail keeps VRA when VR is positive."),

            Keep($"{idPrefix}-SECTION-STD-FL", Section, $"FL@{AnnotationStdFrontPlan}", All(isStd, DimPositive("FL")), "FP PGB STD Section keeps FL."),
            Keep($"{idPrefix}-SECTION-STD-T", Section, $"T@{AnnotationStdFrontPlan}", isStd, "FP PGB STD Section keeps T."),
            Keep($"{idPrefix}-SECTION-REV-FL", Section, $"FL@{AnnotationRevFrontPlan}", All(isRev, DimPositive("FL")), "FP PGB REV Section keeps FL."),
            Keep($"{idPrefix}-SECTION-REV-T", Section, $"T@{AnnotationRevFrontPlan}", isRev, "FP PGB REV Section keeps T.")
        };
    }

    protected IReadOnlyList<AnnotationKeepRule> BuildFgProductionCustomerRules(
        string idPrefix,
        bool includeProductionOnlyRules)
    {
        var isStd = ShankIs(FpAnnotationShankTypes.Std);
        var isRev = ShankIs(FpAnnotationShankTypes.Rev);
        var hasVbl = DimPositive("VBL");
        var noVbl = Not(hasVbl);
        var hasRa2 = DimPositive("RA2");
        var hasCbr = DimsPositive("CBRL", "CBRD");
        var noCbr = Not(hasCbr);
        var froEqualsFr = TraitIs(FpAnnotationTraitNames.FroEqualsFr, FpAnnotationTraitValues.True);
        var froDiffersFromFr = Not(froEqualsFr);
        var isStdHole = FeedHoleIs(FpAnnotationFeedHoleTypes.Standard);
        var isOvalHole = FeedHoleIs(FpAnnotationFeedHoleTypes.Oval);
        var isSlot = FeedHoleIs(FpAnnotationFeedHoleTypes.Slot);
        var isVgFoot = FootIs(FpAnnotationFootOptions.Vg);
        var isGFoot = FootIs(FpAnnotationFootOptions.G);
        var isCFoot = FootIn(FpAnnotationFootOptions.C, FpAnnotationFootOptions.CWithCbr);

        var rules = new List<AnnotationKeepRule>
        {
            Keep($"{idPrefix}-SIDE-STD-BA", Side, $"BA@{AnnotationStdFrontPlan}", All(isStd, noVbl), "FP FG STD Side keeps BA when VBL is not positive."),
            Keep($"{idPrefix}-SIDE-STD-VBL", Side, $"VBL@{AnnotationStdFrontPlan}", All(isStd, hasVbl), "FP FG STD Side keeps VBL when VBL is positive."),
            Keep($"{idPrefix}-SIDE-STD-BA-SLB", Side, $"BA_SLB@{AnnotationStdFrontPlan}", All(isStd, hasVbl), "FP FG STD Side keeps BA_SLB when VBL is positive."),
            Keep($"{idPrefix}-SIDE-REV-BA", Side, $"BA@{AnnotationRevFrontPlan}", All(isRev, noVbl), "FP FG REV Side keeps BA when VBL is not positive."),
            Keep($"{idPrefix}-SIDE-REV-VBL", Side, $"VBL@{AnnotationRevFrontPlan}", All(isRev, hasVbl), "FP FG REV Side keeps VBL when VBL is positive."),
            Keep($"{idPrefix}-SIDE-REV-BA-SLB", Side, $"BA_SLB@{AnnotationRevFrontPlan}", All(isRev, hasVbl), "FP FG REV Side keeps BA_SLB when VBL is positive."),

            Keep($"{idPrefix}-FRONT-TL", Front, $"TL@{AnnotationRightPlan}", Always(), "FP FG Front always keeps TL."),
            Keep($"{idPrefix}-FRONT-VR", Front, $"VR@{AnnotationRightPlan}", DimPositive("VR"), "FP FG Front keeps VR when VR is positive."),

            KeepWithAliases($"{idPrefix}-TOP-TD", Top, $"TD@{AnnotationTopPlan}", new[] { $"TD@{AnnotationTopPlanTemplateTypo}" }, Always(), "FP FG Top always keeps TD."),
            KeepWithAliases($"{idPrefix}-TOP-TDF-STD", Top, $"TDF_STD@{AnnotationTopPlan}", new[] { $"TDF_STD@{AnnotationTopPlanTemplateTypo}" }, isStd, "FP FG Top keeps TDF_STD for SW_STD."),
            KeepWithAliases($"{idPrefix}-TOP-TDF-REV", Top, $"TDF_REV@{AnnotationTopPlan}", new[] { $"TDF_REV@{AnnotationTopPlanTemplateTypo}" }, isRev, "FP FG Top keeps TDF_REV for SW_180REV."),

            Keep($"{idPrefix}-DETAIL-W", Detail, $"W_NOM@{AnnotationRightPlan}", Always(), "FP FG Detail always keeps W."),
            Keep($"{idPrefix}-DETAIL-ISA", Detail, $"ISA@{AnnotationRightPlan}", Always(), "FP FG Detail always keeps ISA."),
            Keep($"{idPrefix}-DETAIL-VW", Detail, $"VW@{AnnotationRightPlan}", DimPositive("VW"), "FP FG Detail keeps VW when VW is positive."),
            Keep($"{idPrefix}-DETAIL-VRA", Detail, $"VRA@{AnnotationRightPlan}", DimPositive("VR"), "FP FG Detail keeps VRA when VR is positive."),
            Keep($"{idPrefix}-DETAIL-VG-B", Detail, $"B_NOM@{AnnotationRightPlan}", isVgFoot, "FP FG Detail keeps B for VG."),
            Keep($"{idPrefix}-DETAIL-VG-GA", Detail, $"GA@{AnnotationRightPlan}", isVgFoot, "FP FG Detail keeps GA for VG."),
            Keep($"{idPrefix}-DETAIL-G-GO", Detail, $"GO@{AnnotationRightPlan}", isGFoot, "FP FG Detail keeps GO for G."),
            Keep($"{idPrefix}-DETAIL-C-CD", Detail, $"CD_NOM@{AnnotationRightPlan}", isCFoot, "FP FG Detail keeps CD for C/C-with-CBR."),

            Keep($"{idPrefix}-SECTION-STD-T", Section, $"T@{AnnotationStdFrontPlan}", isStd, "FP FG STD Section keeps T."),
            Keep($"{idPrefix}-SECTION-STD-RA2", Section, $"RA2@{AnnotationStdFrontPlan}", All(isStd, hasRa2), "FP FG STD Section keeps RA2 when RA2 is positive."),
            Keep($"{idPrefix}-SECTION-STD-FNA", Section, $"FNA@{AnnotationStdFrontPlan}", isStd, "FP FG STD Section keeps FNA."),
            //Keep($"{idPrefix}-SECTION-STD-HA", Section, $"D1@{AnnotationStdFrontPlan}", isStd, "FP FG STD Section keeps HA."),
            Keep($"{idPrefix}-SECTION-STD-H", Section, $"H@{AnnotationStdFrontPlan}", All(isStd, isStdHole), "FP FG STD Section keeps H for a standard hole."),
            Keep($"{idPrefix}-SECTION-STD-HH", Section, $"HH@{AnnotationStdFrontPlan}", All(isStd, isOvalHole), "FP FG STD Section keeps HH for an oval hole."),
            Keep($"{idPrefix}-SECTION-STD-ST", Section, $"ST@{AnnotationStdFrontPlan}", All(isStd, isSlot), "FP FG STD Section keeps ST for a slot."),
            Keep($"{idPrefix}-SECTION-STD-FR", Section, $"FR@{AnnotationStdFrontPlan}", All(isStd, froDiffersFromFr), "FP FG STD Section keeps FR only when FRO differs from FR."),
            Keep($"{idPrefix}-SECTION-STD-BR", Section, $"BR@{AnnotationStdFrontPlan}", All(isStd, noCbr), "FP FG STD Section keeps BR only when CBRL/CBRD do not define CBR."),

            Keep($"{idPrefix}-SECTION-REV-T", Section, $"T@{AnnotationRevFrontPlan}", isRev, "FP FG REV Section keeps T."),
            Keep($"{idPrefix}-SECTION-REV-RA2", Section, $"RA2@{AnnotationRevFrontPlan}", All(isRev, hasRa2), "FP FG REV Section keeps RA2 when RA2 is positive."),
            Keep($"{idPrefix}-SECTION-REV-FNA", Section, $"FNA@{AnnotationRevFrontPlan}", isRev, "FP FG REV Section keeps FNA."),
            //Keep($"{idPrefix}-SECTION-REV-HA", Section, $"HA@{AnnotationRevFrontPlan}", isRev, "FP FG REV Section keeps HA."),
            Keep($"{idPrefix}-SECTION-REV-H", Section, $"H@{AnnotationRevFrontPlan}", All(isRev, isStdHole), "FP FG REV Section keeps H for a standard hole."),
            Keep($"{idPrefix}-SECTION-REV-HH", Section, $"HH@{AnnotationRevFrontPlan}", All(isRev, isOvalHole), "FP FG REV Section keeps HH for an oval hole."),
            Keep($"{idPrefix}-SECTION-REV-ST", Section, $"ST@{AnnotationRevFrontPlan}", All(isRev, isSlot), "FP FG REV Section keeps ST for a slot."),
            Keep($"{idPrefix}-SECTION-REV-FR", Section, $"fr@{AnnotationRevFrontPlan}", All(isRev, froDiffersFromFr), "FP FG REV Section keeps FR only when FRO differs from FR."),
            Keep($"{idPrefix}-SECTION-REV-BR", Section, $"BR@{AnnotationRevFrontPlan}", All(isRev, noCbr), "FP FG REV Section keeps BR only when CBRL/CBRD do not define CBR."),
        };

        if (!includeProductionOnlyRules)
            return rules;

        // FG Production-only dimensions:
        // W2, GD, CL, FL, RA, CA, FD, ERL and FRO are intentionally
        // excluded from Customer drawings and retained only in Production.
        //rules.Add(Keep($"{idPrefix}-DETAIL-PROD-W2", Detail, $"W2@{AnnotationRightPlan}", Always(), "FP FG Production Detail keeps W2."));
        rules.Add(Keep($"{idPrefix}-DETAIL-PROD-VG-GD", Detail, $"GD@{AnnotationRightPlan}", isVgFoot, "FP FG Production Detail keeps GD for VG."));
        rules.Add(Keep($"{idPrefix}-DETAIL-PROD-G-GD", Detail, $"GD_G@{AnnotationRightPlan}", isGFoot, "FP FG Production Detail keeps GD_G for G."));
        rules.Add(Keep($"{idPrefix}-DETAIL-PROD-C-CL", Detail, $"CL@{AnnotationRightPlan}", isCFoot, "FP FG Production Detail keeps CL for C/C-with-CBR."));

        rules.Add(Keep($"{idPrefix}-SECTION-PROD-STD-FL", Section, $"FL@{AnnotationStdFrontPlan}", isStd, "FP FG Production STD Section keeps FL."));
        rules.Add(Keep($"{idPrefix}-SECTION-PROD-STD-RA", Section, $"RA@{AnnotationStdFrontPlan}", isStd, "FP FG Production STD Section keeps RA."));
        //rules.Add(Keep($"{idPrefix}-SECTION-PROD-STD-CA", Section, $"CA@{AnnotationStdFrontPlan}", isStd, "FP FG Production STD Section keeps CA."));
        rules.Add(Keep($"{idPrefix}-SECTION-PROD-STD-FD", Section, $"FD@{AnnotationStdFrontPlan}", isStd, "FP FG Production STD Section keeps FD."));
        //rules.Add(Keep($"{idPrefix}-SECTION-PROD-STD-ERL", Section, $"ERL@{AnnotationStdFrontPlan}", isStd, "FP FG Production STD Section keeps ERL."));
        rules.Add(Keep($"{idPrefix}-SECTION-PROD-STD-FRO", Section, $"FRO@{AnnotationStdFrontPlan}", isStd, "FP FG Production STD Section keeps FRO."));

        rules.Add(Keep($"{idPrefix}-SECTION-PROD-REV-FL", Section, $"FL@{AnnotationRevFrontPlan}", isRev, "FP FG Production REV Section keeps FL."));
        rules.Add(Keep($"{idPrefix}-SECTION-PROD-REV-RA", Section, $"RA@{AnnotationRevFrontPlan}", isRev, "FP FG Production REV Section keeps RA."));
        //rules.Add(Keep($"{idPrefix}-SECTION-PROD-REV-CA", Section, $"CA@{AnnotationRevFrontPlan}", isRev, "FP FG Production REV Section keeps CA."));
        rules.Add(Keep($"{idPrefix}-SECTION-PROD-REV-FD", Section, $"D1@{AnnotationRevFrontPlan}", isRev, "FP FG Production REV Section keeps FD."));
        //rules.Add(Keep($"{idPrefix}-SECTION-PROD-REV-ERL", Section, $"ERL@{AnnotationRevFrontPlan}", isRev, "FP FG Production REV Section keeps ERL."));
        rules.Add(Keep($"{idPrefix}-SECTION-PROD-REV-FRO", Section, $"FRO@{AnnotationRevFrontPlan}", isRev, "FP FG Production REV Section keeps FRO."));

        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-STD-BF", Section, $"BF@{AnnotationFrontPlan}", new[] { $"BF@{AnnotationStdFrontPlan}" }, isStd, "FP FG Production STD Section keeps BF."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-STD-F", Section, $"F@{AnnotationFrontPlan}", new[] { $"F@{AnnotationStdFrontPlan}" }, isStd, "FP FG Production STD Section keeps F."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-STD-Y", Section, $"Y@{AnnotationFrontPlan}", new[] { $"Y@{AnnotationStdFrontPlan}" }, isStd, "FP FG Production STD Section keeps Y."));
        //rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-STD-CBRL", Section, $"CBRL@{AnnotationFrontPlan}", new[] { $"CBRL@{AnnotationStdFrontPlan}" }, isStd, "FP FG Production STD Section keeps CBRL."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-STD-CBRA", Section, $"CBRA@{AnnotationFrontPlan}", new[] { $"CBRA@{AnnotationStdFrontPlan}" }, isStd, "FP FG Production STD Section keeps CBRA."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-REV-BF", Section, $"BF@{AnnotationRevPlan}", new[] { $"BF@{AnnotationRevFrontPlan}" }, isRev, "FP FG Production REV Section keeps BF."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-REV-F", Section, $"F@{AnnotationRevPlan}", new[] { $"F@{AnnotationRevFrontPlan}" }, isRev, "FP FG Production REV Section keeps F."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-REV-Y", Section, $"Y@{AnnotationRevPlan}", new[] { $"Y@{AnnotationRevFrontPlan}" }, isRev, "FP FG Production REV Section keeps Y."));
        //rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-REV-CBRL", Section, $"CBRL@{AnnotationRevPlan}", new[] { $"CBRL@{AnnotationRevFrontPlan}" }, isRev, "FP FG Production REV Section keeps CBRL."));
        rules.Add(KeepWithAliases($"{idPrefix}-SECTION-PROD-REV-CBRA", Section, $"CBRA@{AnnotationRevPlan}", new[] { $"CBRA@{AnnotationRevFrontPlan}" }, isRev, "FP FG Production REV Section keeps CBRA."));

        return rules;
    }

    protected static IReadOnlyList<AnnotationKeepRule> BuildEmptyOverlayRules()
        => Array.Empty<AnnotationKeepRule>();
}

public sealed class FpFgProductionAnnotationRules : FpAnnotationRuleCatalogBase
{
    public override AnnotationCleanupProfile Profile => AnnotationCleanupProfile.FpFgProduction;
    public override IReadOnlyList<AnnotationKeepRule> Rules { get; }

    public FpFgProductionAnnotationRules()
        => Rules = BuildFgProductionCustomerRules("FP-FG-PROD", includeProductionOnlyRules: true);
}

public sealed class FpFgCustomerAnnotationRules : FpAnnotationRuleCatalogBase
{
    public override AnnotationCleanupProfile Profile => AnnotationCleanupProfile.FpFgCustomer;
    public override IReadOnlyList<AnnotationKeepRule> Rules { get; }

    public FpFgCustomerAnnotationRules()
        => Rules = BuildFgProductionCustomerRules("FP-FG-CUST", includeProductionOnlyRules: false);
}

public sealed class FpFgOverlayAnnotationRules : FpAnnotationRuleCatalogBase
{
    public override AnnotationCleanupProfile Profile => AnnotationCleanupProfile.FpFgOverlay;
    public override IReadOnlyList<AnnotationKeepRule> Rules { get; } = BuildEmptyOverlayRules();
}

public sealed class FpPgbProductionAnnotationRules : FpAnnotationRuleCatalogBase
{
    public override AnnotationCleanupProfile Profile => AnnotationCleanupProfile.FpPgbProduction;
    public override IReadOnlyList<AnnotationKeepRule> Rules { get; }

    public FpPgbProductionAnnotationRules()
        => Rules = BuildPgbProductionCustomerRules("FP-PGB-PROD");
}

public sealed class FpPgbOverlayAnnotationRules : FpAnnotationRuleCatalogBase
{
    public override AnnotationCleanupProfile Profile => AnnotationCleanupProfile.FpPgbOverlay;
    public override IReadOnlyList<AnnotationKeepRule> Rules { get; } = BuildEmptyOverlayRules();
}